package ca.hullabaloo.util;

/**
 * Constant class with convenience calculations for the number of milliseconds
 * in a second, minute, hour, etc
 * 
 * @author Darren Gilroy
 */
public class Milliseconds {
	public static final long ONE_SECOND = 1000L;

	public static final long ONE_MINUTE = 60L * ONE_SECOND;

	public static final long ONE_HOUR = 60L * ONE_MINUTE;

	public static final long ONE_DAY = 24L * ONE_HOUR;

	public static final long ONE_WEEK = 7L * ONE_DAY;
}
