package ca.hullabaloo.util;

/**
 * From http://java.sun.com/developer/JDCTechTips/2002/tt0604.html
 */
public class ArrayCharSequence implements CharSequence {
	private char[] vec;

	private int off;

	private int len;

	/** Construct a ArrayCharSequence from a char array */
	public ArrayCharSequence() {
		// must set char array before use
	}

	/** Construct a ArrayCharSequence from a char array */
	public ArrayCharSequence(char[] ch) {
		this(ch, 0, ch.length);
	}

	/** set the character array */
	public void setCharArray(char[] ch) {
		setCharArray(ch, 0, ch.length);
	}

	/** set the character array */
	public void setCharArray(char[] ch, int start, int length) {
		if (ch == null) {
			throw new NullPointerException("null vec");
		}
		if (start < 0 || length < 0 || start > ch.length - length) {
			throw new IllegalArgumentException("bad off/len");
		}
		this.vec = ch;
		this.off = start;
		this.len = length;
	}

	/** construct an CharArrayWrapper from a portion of a char array */
	public ArrayCharSequence(char ch[], int start, int length) {
		setCharArray(ch, start, length);
	}

	/** length of sequence */
	public int length() {
		return len;
	}

	/** character at a given index */
	public char charAt(int index) {
		if (index < 0 || index >= len) {
			throw new IndexOutOfBoundsException("invalid index");
		}
		return vec[index + off];
	}

	/** subsequence from start (inclusive) to end (exclusive) */
	public CharSequence subSequence(int start, int end) {
		if (start < 0 || end < 0 || end > len || start > end) {
			throw new IndexOutOfBoundsException("invalid start/end");
		}
		return new ArrayCharSequence(vec, start + off, end - start);
	}

	/** convert to string */
	@Override
	public String toString() {
		return new String(vec, off, len);
	}

}