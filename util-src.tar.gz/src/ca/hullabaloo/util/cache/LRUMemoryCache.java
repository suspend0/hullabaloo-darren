package ca.hullabaloo.util.cache;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Least-Recently-Used cache that stores stuff in memory.
 * 
 * @author Darren Gilroy
 */
public class LRUMemoryCache implements FixedSizeCache {

	/** The default capacity */
	private static final int DEFAULT_CAPACITY = 16;

	/** Since this is a LinkedHashMap, it MUST be synchronized externally */
	private final Map<Object, Entry> m_map;

	/** the capacity */
	private final int m_capacity;

	/**
	 * Creates a new LRUMemoryCache object.
	 * 
	 * @param maxCapacity
	 */
	public LRUMemoryCache(final int maxCapacity) {
		m_capacity = maxCapacity;
		m_map = new LinkedHashMap<Object, Entry>(m_capacity + 1, 0.75F, true) {
			private static final long serialVersionUID = 1L;

			protected boolean removeEldestEntry(Map.Entry eldest) {
				if (size() > m_capacity) {
					return true;
				} else {
					return false;
				}
			}
		};
	}

	/**
	 * Creates a new LRUMemoryCache object.
	 */
	public LRUMemoryCache() {
		this(DEFAULT_CAPACITY);
	}

	/**
	 * Returns the maximum capacity of this class
	 * 
	 * @return capaciy
	 */
	public int capacity() {
		return m_capacity;
	}

	/**
	 * Clears all of the elements in the cache
	 */
	public synchronized void clear() {
		m_map.clear();
	}

	/**
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache#get(java.lang.Object)
	 */
	public synchronized Entry get(Object key) {
		Entry entry = (Entry) m_map.get(key);

		return entry;
	}

	/**
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache#put(com.fujitsu.fbf.fbf2.util.cache.Cache.Entry)
	 */
	public synchronized Entry put(Entry entry) {
		return (Entry) m_map.put(entry.key(), entry);
	}

	/**
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache#remove(java.lang.Object)
	 */
	public synchronized Entry remove(Object key) {
		return (Entry) m_map.remove(key);
	}
}
