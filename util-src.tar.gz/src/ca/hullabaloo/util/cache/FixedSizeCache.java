package ca.hullabaloo.util.cache;

/**
 * Defines caches which implement a fixed maximum capacity.
 */
public interface FixedSizeCache extends Cache {
	/**
	 * Returns the maximum capacity of this Cache
	 * 
	 * @return cpacity
	 */
	public int capacity();
}
