package ca.hullabaloo.util.cache;

/**
 * Allows retrieval of a cache by name.
 * 
 * @author Darren Gilroy
 */
public interface CacheManager {
	/**
	 * returns a cache with the given name
	 * 
	 * @return a cache
	 */
	public Cache getCache(Object key);

	/**
	 * Clears all caches managed by this cache manager
	 */
	public void clear();
}
