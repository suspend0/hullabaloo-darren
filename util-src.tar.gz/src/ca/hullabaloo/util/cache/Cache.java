package ca.hullabaloo.util.cache;

/**
 * A simple cache interface.
 * 
 * <p>
 * Implementations of this interface must be thread-safe.
 * </p>
 * 
 * @author Darren Gilroy
 */
public interface Cache {
	/**
	 * Clears the cache of all entries.
	 */
	public void clear();

	/**
	 * Returns an entry from the cache.
	 * 
	 * @param key
	 * 
	 * @return entry
	 */
	public Entry get(Object key);

	/**
	 * Puts an entry into the cache.
	 * 
	 * @param entry
	 * 
	 * @return the previous entry mapped to this key, or null.
	 */
	public Entry put(Entry entry);

	/**
	 * Removes an entry from the cache.
	 * 
	 * @param key
	 * 
	 * @return the previous entry mapped to this key, or null.
	 */
	public Entry remove(Object key);

	/**
	 * Defines an entry in the cache.
	 */
	public interface Entry {
		/**
		 * Changes the value of this entry.
		 * 
		 * @param val
		 */
		public void setValue(Object val);

		/**
		 * Returns this entry's key.
		 * 
		 * @return key
		 */
		public Object key();

		/**
		 * Returns the last modified time of this entry.
		 * 
		 * @return modified time
		 */
		public long lastModified();

		/**
		 * The value of the entry.
		 * 
		 * @return The version number of the entry.
		 */
		public Object value();
	}
}
