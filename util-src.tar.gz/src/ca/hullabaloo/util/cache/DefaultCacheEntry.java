package ca.hullabaloo.util.cache;

/**
 * A default implementation for {@link Cache.Entry}. Extensions to this class
 * should be sure to call {@link #setValue(Object)} so that
 * {@link #lastModified()} is kept up-to-date.
 * 
 * @author Darren Gilroy
 */
public class DefaultCacheEntry implements Cache.Entry {
	private final Object m_key;

	private Object m_val;

	private long m_lastModified;

	/**
	 * Creates a new DefaultCacheEntry object.
	 * 
	 * @param key
	 * 
	 * @throws NullPointerException
	 */
	public DefaultCacheEntry(Object key) {
		if (key == null) {
			throw new NullPointerException("Null keys are not supported");
		}

		m_key = key;
	}

	/**
	 * Creates a new DefaultCacheEntry object.
	 * 
	 * @param key
	 * @param value
	 */
	public DefaultCacheEntry(Object key, Object value) {
		this(key);
		setValue(value);
	}

	/**
	 * Sets the last modified time, without changing the value
	 * 
	 * @param mod
	 *            modified time
	 */
	public void setLastModified(long mod) {
		m_lastModified = mod;
	}

	/**
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache.Entry#setValue(java.lang.Object)
	 */
	public void setValue(Object val) {
		m_val = val;
		m_lastModified = System.currentTimeMillis();
	}

	/**
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache.Entry#key()
	 */
	public Object key() {
		return m_key;
	}

	/**
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache.Entry#lastModified()
	 */
	public long lastModified() {
		return m_lastModified;
	}

	/**
	 * Since the values are held as SoftReferences, the value may return NULL.
	 * 
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache.Entry#value()
	 */
	public Object value() {
		return m_val;
	}

	/**
	 * Sets the last modified time to the current time.
	 */
	protected void setLastModified() {
		m_lastModified = System.currentTimeMillis();
	}
}
