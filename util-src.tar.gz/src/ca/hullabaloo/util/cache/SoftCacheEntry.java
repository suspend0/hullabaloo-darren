package ca.hullabaloo.util.cache;

import java.lang.ref.SoftReference;

/**
 * Implements a Cache.Entry that holds its data as a soft reference.
 * 
 * @author Darren Gilroy
 */
public class SoftCacheEntry extends DefaultCacheEntry implements Cache.Entry {
	/**
	 * Creates a new SoftCacheEntry object.
	 * 
	 * @param key
	 *            This object's key
	 */
	public SoftCacheEntry(Object key) {
		super(key);
	}

	/**
	 * Creates a new SoftCacheEntry object.
	 * 
	 * @param key
	 *            This object's key
	 * @param value
	 *            the initial value
	 */
	public SoftCacheEntry(Object key, Object value) {
		super(key);
		setValue(value);
	}

	/**
	 * Sets the value.
	 * 
	 * @param val
	 *            the new value (stored as a soft reference)
	 */
	public void setValue(Object val) {
		super.setValue(new SoftReference<Object>(val));
	}

	/**
	 * Since the values are held as SoftReferences, the value may return NULL.
	 * 
	 * @see com.fujitsu.fbf.fbf2.util.cache.Cache.Entry#value()
	 */
	public Object value() {
		SoftReference val = (SoftReference) super.value();

		return (val == null) ? null : val.get();
	}
}
