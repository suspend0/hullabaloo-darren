package ca.hullabaloo.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * This class contains a very simple parseQueryString static method to parse the
 * URL query strings.
 * 
 * @author Darren Gilroy
 */
public class QueryStringParser {

	/** Should not be constructed in standard programming */
	public QueryStringParser() {
		// no-op
	}

	/**
	 * parseQueryString is a simple URL query string parser. It does not handle
	 * multiple parameters with the same name
	 * 
	 * @param queryString
	 * @return Map<String,String> with the parameter names and their values
	 */
	public static Map<String, String> parseQueryString(final String queryString) {
		final HashMap<String, String> map = new HashMap<String, String>();

		final NameValueCallback cb = new NameValueCallback() {
			public void nameValuePair(final CharSequence keySeq,
					final CharSequence valueSeq) {
				try {
					String key = URLDecoder.decode(keySeq.toString(), "UTF-8");
					String value = URLDecoder.decode(valueSeq.toString(),
							"UTF-8");
					map.put(key, value);
				} catch (UnsupportedEncodingException e) {
					// This should never happen -- UTF-8 is hardcoded
					throw new RuntimeException(
							"UnsupportedEncodingException in parseQueryString for UTF-8");
				}
			}

		};

		// This populates the map
		parseNameValuePairs(queryString, '&', '=', cb);

		return map;
	}

	/** Parses a string of name-values pairs into a map */
	public static Map<String, String> parseNameValuePairs(
			final CharSequence str, final char betweenPairs,
			final char withinPairs) {
		final LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

		final NameValueCallback cb = new NameValueCallback() {
			public void nameValuePair(final CharSequence keySeq,
					final CharSequence valueSeq) {
				map.put(keySeq.toString(), valueSeq.toString());
			}
		};

		// This populates the map
		parseNameValuePairs(str, betweenPairs, withinPairs, cb);

		return map;
	}

	/**
	 * Parses a string of name-values pairs and sends them to the provided
	 * callback
	 */
	public static void parseNameValuePairs(final CharSequence str,
			final char betweenPairs, final char withinPairs,
			final NameValueCallback callback) {
		// NOTE: the comments below assume strings like "abc=d;fd=qr;gey=rez",
		// where betweenPairs is
		// ';' and withinPairs is '='
		if (str == null)
			return;

		int pos = 0;
		int len = str.length();

		// ignore leading ';'
		while (str.charAt(pos) == betweenPairs)
			pos++;

		char c = '\0';
		int begin = pos, middle = pos;
		while (pos < len) {
			c = str.charAt(pos);
			// scan for '='
			if (c == withinPairs) {
				middle = pos;
				pos++;
				// scan for ';' terminating a scan
				for (; pos < len; pos++) {
					c = str.charAt(pos);
					if (c == betweenPairs) {
						CharSequence key = str.subSequence(begin, middle);
						CharSequence val = str.subSequence(middle + 1, pos);
						callback.nameValuePair(key, val);
						begin = middle = pos + 1;
						break;
					}
				}
			}
			// scan for ';' for keys with no value
			else if (c == betweenPairs) {
				// (pos > begin) traps ';;'
				if (pos > begin) {
					CharSequence key = str.subSequence(begin, pos);
					callback.nameValuePair(key, "");
				}
				begin = middle = pos + 1;
			}
			pos++;
		}

		// (pos > begin) traps trailing ';'
		if (pos > begin) {
			// (inval) for cases like "hello" in "ad=adf;hello;af=3d"
			if (middle > begin) {
				pos--;
				CharSequence key = str.subSequence(begin, middle);
				CharSequence val = str.subSequence(middle + 1, pos);
				callback.nameValuePair(key, val);
			} else {
				CharSequence key = str.subSequence(begin, pos);
				callback.nameValuePair(key, "");
			}
		}
	}

	/** Used by the parser */
	public interface NameValueCallback {
		public void nameValuePair(CharSequence key, CharSequence val);
	}

	/** Removes a parameter (and its value) from the passed query string */
	public static void removeParam(StringBuilder qs, String param) {
		if (qs == null || param == null)
			return;

		if (qs.length() == 0 || param.length() == 0)
			return;

		if (qs.length() == param.length()) {
			// this is just a faster way to say "equals" since lengths are equal
			if (qs.indexOf(param) != -1)
				qs.setLength(0);
			return;
		}

		// Find start, bail if param not found
		int start = indexOfParam(qs, param, 0);
		if (start == -1)
			return;

		// find end
		int end = start + param.length();
		int len = qs.length();
		for (; end < len; end++) {
			char ch = qs.charAt(end);
			if (ch == '&' || ch == ';')
				break;
		}

		// shift the end points so we delete one of the delimiters
		if (end == len)
			start -= (start == 0) ? 0 : 1;
		else
			end++;

		qs.delete(start, end);
	}

	/** Returns the index of the first character of the parameter */
	private static int indexOfParam(StringBuilder qs, String param, int idx) {
		int start = qs.indexOf(param, idx);
		char c;
		switch (start) {
		case -1:
			// not found, no changes
			return -1;
		case 0:
			// at start of QS, check after
			c = qs.charAt(param.length());
			if (c == '=' || c == '&' || c == ';')
				return 0;
			else
				return indexOfParam(qs, param, param.length());
		default:
			// check the preceding delimiter
			c = qs.charAt(start - 1);
			if ((false == (c == '&' || c == ';')))
				return indexOfParam(qs, param, start + param.length());
			// check the following delimiter
			int pos = start + param.length();
			// end of qs?
			if (pos == qs.length())
				return start;
			c = qs.charAt(pos);
			if ((false == (c == '=' || c == '&' || c == ';')))
				return indexOfParam(qs, param, start + param.length());
			return start;
		}

	}
}
