package ca.hullabaloo.util.text;

import java.text.BreakIterator;
import java.text.CollationKey;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

/**
 * A phrase matcher that uses the Aho-Corasick algorithm to search for any
 * number of phrases in an input string. Uses {@link java.text.BreakIterator} to
 * split the words and {@link java.text.Collator} to compare so should work well
 * for any language supported by Java.
 * 
 * <p>
 * <b>Note:</b> This class is meant to match multiple match strings against an
 * input pattern. If you want to match a single phrase, look elsewhere.
 * </p>
 * 
 * <p>
 * This class is thread safe for multiple concurrent calls to
 * {@link #match(String, PhraseMatchListener)}, after prepareTree() has been
 * called an assuming no intervening calls to any of the <code>set</code>
 * methods.
 * </p>
 * 
 * @author Darren Gilroy
 */
public class AhoCorasickPhraseMatcher implements PhraseMatcher {
	/** Our tree of search terms */
	private AhoCorasickTree tree;

	/**
	 * The locale. Used to extract words from the strings and to create the
	 * Collator.
	 */
	private Locale locale = Locale.getDefault();

	/** The strings to search for */
	private Phrase[] find;

	/** If this search is case sensitive */
	private int collationStrength = Collator.TERTIARY;

	/**
	 * Creates a new AhoCorasickPhraseMatcher. You must call
	 * {@link #setSearch(Collection)}and {@link #prepareTree()} before
	 * searching.
	 */
	public AhoCorasickPhraseMatcher() {
	}

	/**
	 * Sets if this search should test with case sensitivity. Defaults to
	 * <code>true</code>.
	 * 
	 * <p>
	 * After setting this you must call {@link #prepareTree()}before searching.
	 * </p>
	 * 
	 * @param caseSensitive
	 *            true if this search is case sensitive
	 */
	public void setCaseSensitivity(boolean caseSensitive) {
		setCollationStrength(caseSensitive ? Collator.TERTIARY
				: Collator.PRIMARY);
	}

	/**
	 * Sets the collation strength used by the underlying collator. For most
	 * languages you're better off calling {@link #setCaseSensitivity(boolean)}.
	 * 
	 * <p>
	 * After setting this you must call {@link #prepareTree()}before searching.
	 * </p>
	 * 
	 * @param strength
	 *            must be Collator.IDENTICAL, Collator.PRIMARY,
	 *            Collator.SECONDARY or Collator.TERTIARY
	 * 
	 * @throws IllegalArgumentException
	 *             invalid strength
	 */
	public void setCollationStrength(int strength) {
		if ((strength == Collator.IDENTICAL) || (strength == Collator.PRIMARY)
				|| (strength == Collator.SECONDARY)
				|| (strength == Collator.TERTIARY)) {
			this.collationStrength = strength;
		} else {
			throw new IllegalArgumentException("Invalid collation strength "
					+ strength);
		}

		tree = null;
	}

	/**
	 * Sets the locale to use when searching.
	 * 
	 * <p>
	 * After setting this you must call {@link #prepareTree()}before searching.
	 * </p>
	 * 
	 * @param locale
	 *            the local to use for this object.
	 */
	public void setLocale(Locale locale) {
		this.locale = (locale == null) ? Locale.getDefault() : locale;
		tree = null;
	}

	/**
	 * Sets the search strings to search for. This collection must contain only
	 * {@link String}objects, and will throw a {@link ClassCastException}if
	 * any of the objects in this collection are not Strings.
	 * 
	 * <p>
	 * After setting this you must call {@link #prepareTree()}before searching.
	 * </p>
	 * 
	 * @param searchForStrings
	 *            the locale to use for this object.
	 */
	public void setSearch(Collection<String> searchForStrings) {
		// use the set to remove duplicates
		Set<String> set = new HashSet<String>(searchForStrings);

		// this is the array we're initializing
		this.find = new Phrase[set.size()];

		int idx = 0;

		for (Iterator i = set.iterator(); i.hasNext(); idx++) {
			find[idx] = new Phrase((String) i.next());
		}

		// always reset the tree
		this.tree = null;
	}

	/**
	 * Test method
	 * 
	 * @param args
	 *            Test
	 */
	public static void main(String[] args) {
		System.out.println("Running...");

		int TEST = 1;

		if (TEST == 1) {
			AhoCorasickPhraseMatcher ac = new AhoCorasickPhraseMatcher();
			Collection<String> find = new ArrayList<String>();
			find.add("hello there how are you");
			find.add("Hello there");
			find.add("there Are");
			find.add("how is mom");
			find.add("are there");
			find.add("there are");

			String findIn = "bob hello there how are you a are There are test";

			ac.setSearch(find);
			ac.setCaseSensitivity(false);
			ac.prepareTree();

			// TestPrinter.printGraph(ac.tree.root);
			PhraseMatchListener listener = new PhraseMatchListener() {
				public void matched(CharSequence input, int start, int length,
						CharSequence phrase, int wordNumber, int wordCount) {
					CharSequence found = input.subSequence(start, start
							+ length);
					System.out.println("match :[" + found + "]");
					System.out.println("search:[" + phrase + "]");
					System.out.println("    wordCount:" + wordCount
							+ " wordNumber:" + wordNumber + " charIndex:"
							+ start);
				}
			};

			ac.match(findIn, listener);
		}
	}

	/**
	 * Search the input for any of the search strings
	 * 
	 * @param input
	 *            the input to look for phrases in
	 * @param listener
	 *            gets matching phrases
	 * 
	 * @throws IllegalStateException
	 *             if prepareTree() has not been called.
	 */
	public void match(String input, PhraseMatchListener listener) {
		if (tree == null) {
			throw new IllegalStateException(
					"Must call prepareTree() before searching");
		}

		// hold our partial matches
		AhoCorasickTree.Node[] found = new AhoCorasickTree.Node[find.length];
		int foundCount = 0;

		// break our input into words
		BreakIterator boundary = BreakIterator.getWordInstance(locale);
		boundary.setText(input);

		int start = boundary.first();
		int wordNumber = 0;

		for (int end = boundary.next(); end != BreakIterator.DONE; start = end, end = boundary
				.next()) {
			// ignore things that don't start with a character
			if (Character.isLetter(input.charAt(start))) {
				CollationKey word = tree.getCollationKey(input.substring(start,
						end));
				wordNumber++;

				for (int i = 0; i < foundCount; i++) {
					AhoCorasickTree.Node next = found[i].getChild(word);

					if (next == null) {
						// this partial match failed
						found[i] = null;

						// fill this slot and redo
						if (--foundCount > i) {
							found[i] = found[foundCount];
							i++;
						}
					} else if (next.isEndOf()) {
						// this was successful!!
						Phrase matched = find[next.getEndOf()];
						int startingWord = wordNumber - matched.wordCount;
						int startingChar = end - matched.length;
						listener
								.matched(input, startingChar, matched.length,
										matched.phrase, startingWord,
										matched.wordCount);

						// there may be longer matches for this partial
						found[i] = next;
					} else {
						// this partial match is still going
						found[i] = next;
					}
				}

				// finally, try to find find word from the root
				// FROM_ROOT:
				{
					AhoCorasickTree.Node next = tree.getChild(word);

					if (next != null) {
						// single-word match
						if (next.isEndOf()) {
							Phrase matched = find[next.getEndOf()];
							int startingWord = wordNumber - matched.wordCount;
							int startingChar = end - matched.length;
							listener.matched(input, startingChar,
									matched.length, matched.phrase,
									startingWord, matched.wordCount);
						} else {
							found[foundCount++] = next;
						}
					}
				}
			}
		}
	}

	/**
	 * Builds the internal data tree used during the search. This method must be
	 * called before searching.
	 */
	public void prepareTree() {
		if (locale == null) {
			locale = Locale.getDefault();
		}

		this.tree = new AhoCorasickTree(locale, collationStrength);

		// loop over each phrase to find and split it into words
		for (int i = 0; i < find.length; i++) {
			// add the phrase to the search tree
			tree.addPhrase(i, find[i].getWords());
		}
	}

	/**
	 * Simply wraps a string with the number of words it has. Note the wordcount
	 * variable doesn't have a lot of meaning until getWords is called. Not a
	 * very tidy class so it should not be given to an end user.
	 */
	private class Phrase {
		/** the phrase itself */
		private String phrase;

		/**
		 * the length of the phrase -- this may be different in uppercase than
		 * it is in lowercase, so this is set in {@link #getWords()}.
		 */
		private int length;

		/** the number of words in the phrase */
		private int wordCount = -1;

		/**
		 * Create a new phrase
		 * 
		 * @param phrase
		 *            the phrase text
		 */
		public Phrase(String phrase) {
			this.phrase = phrase;
			this.length = phrase.length();
		}

		/**
		 * Gets the words of this phrase, and records the count in
		 * {@link #wordCount}.
		 * 
		 * @return the words in the phrase
		 */
		public Collection getWords() {
			Collection<String> words = new ArrayList<String>();
			BreakIterator boundary = BreakIterator.getWordInstance(locale);
			boundary.setText(phrase);

			int start = boundary.first();

			for (int end = boundary.next(); end != BreakIterator.DONE; start = end, end = boundary
					.next()) {
				if (Character.isLetter(phrase.charAt(start))) {
					String word = phrase.substring(start, end);
					words.add(word);
				}
			}

			this.wordCount = words.size();

			return words;
		}
	}
}
