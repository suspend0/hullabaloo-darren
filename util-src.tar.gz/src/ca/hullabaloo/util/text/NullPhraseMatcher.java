package ca.hullabaloo.util.text;

/**
 * A phrase matcher that does nothing
 * 
 * @author Darren Gilroy
 * @version $Revision: 1.2 $
 */
public class NullPhraseMatcher implements PhraseMatcher {
	/**
	 * A no-op method
	 * 
	 * @param input
	 *            ignored
	 * @param listener
	 *            ignored
	 */
	public void match(String input, PhraseMatchListener listener) {
		// no-op
	}
}
