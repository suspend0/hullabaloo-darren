package ca.hullabaloo.util.text;

import java.text.BreakIterator;
import java.text.CollationKey;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

/**
 * The internal search tree for the {@link AhoCorasickPhraseMatcher} class. The
 * tree is a simple top-down graph. This is our finite automation data.
 */
class AhoCorasickTree {
	/** This is used to sort and compare nodes */
	private final Collator collator;

	/** The root node of the tree */
	private Node root;

	/**
	 * Creates a new AhoCorasickTree object.
	 * 
	 * @param locale
	 *            The locale of the tree
	 * @param collatorStrength
	 *            if the tree should be case sensitive
	 */
	public AhoCorasickTree(Locale locale, int collatorStrength) {
		this.collator = Collator.getInstance(locale);
		this.collator.setStrength(collatorStrength);

		// must happen after Collator is set
		root = new HashNode(null);
	}

	/**
	 * Gets the child of the root node that compares with the passed word.
	 * 
	 * @param word
	 *            the word to search for
	 * 
	 * @return a child, or null if one does not exist
	 */
	public Node getChild(CollationKey word) {
		return root.getChild(word);
	}

	/**
	 * Create a collation key for a word. This key is valid only in this tree.
	 * 
	 * @param word
	 *            the word to base the key on
	 * 
	 * @return a new collation key
	 */
	public CollationKey getCollationKey(String word) {
		return collator.getCollationKey(word);
	}

	/**
	 * Adds a phrase to the tree.
	 * 
	 * @param id
	 *            the ID of this phrase
	 * @param words
	 *            the words in the phrase
	 */
	public void addPhrase(int id, Collection words) {
		Node current = root;

		for (Iterator i = words.iterator(); i.hasNext();) {
			current = current.appendChild((String) i.next());
		}

		current.setEndOf(id);
	}

	/**
	 * Testing method
	 * 
	 * @param args
	 *            args!
	 * 
	 * @throws Exception
	 *             never
	 */
	public static final void main(String[] args) throws Exception {
		AhoCorasickTree tree = new AhoCorasickTree(Locale.US, Collator.PRIMARY);

		// phrase 1
		String[] phrases = { "hello there", "hello there how are you",
				"hello, what is the time there" };

		addPhrase(tree, phrases);

		// optimize
		tree.optimize();

		// print
		TestPrinter.printGraph(tree.root);
	}

	/**
	 * Optimizes the internal structure of the tree. Calling this method makes
	 * the tree immutable.
	 */
	public void optimize() {
		this.root = optimizeNodeType(root);
	}

	/**
	 * Testing method
	 * 
	 * @param tree
	 *            tree to add to
	 * @param phrases
	 *            phrases to add
	 */
	private static void addPhrase(AhoCorasickTree tree, String[] phrases) {
		for (int i = 0; i < phrases.length; i++) {
			String phrase = phrases[i];
			Collection<String> words = new ArrayList<String>();
			BreakIterator boundary = BreakIterator.getWordInstance();
			boundary.setText(phrase);

			int start = boundary.first();

			for (int end = boundary.next(); end != BreakIterator.DONE; start = end, end = boundary
					.next()) {
				if (Character.isLetter(phrase.charAt(start))) {
					String word = phrase.substring(start, end);
					words.add(word);
				}
			}

			tree.addPhrase(i, words);
		}
	}

	/**
	 * Optimizes the node type based on the number of children this node has.
	 * This implementation only supports the optimization of
	 * <code>HashNode</code>s.
	 * 
	 * @param node
	 *            the node to optimize
	 * 
	 * @return an equivalent node of a (possibly) different type.
	 */
	private Node optimizeNodeType(Node node) {
		if (!(node instanceof HashNode)) {
			return node;
		}

		Set<Node> children = new HashSet<Node>();

		// OPTIMIZE_CHILDREN:
		{
			HashNode hashNode = (HashNode) node;

			for (Iterator i = hashNode.children.values().iterator(); i
					.hasNext();) {
				children.add(optimizeNodeType((Node) i.next()));
			}
		}

		int count = children.size();

		if (count == 0) {
			Node n = new NoChildNode(node.value());
			n.setEndOf(node.getEndOf());

			return n;
		}

		if (count == 1) {
			Node n = new SingleChildNode(node.value(), children);
			n.setEndOf(node.getEndOf());

			return n;
		}

		if (count == 2) {
			Node n = new TwoChildNode(node.value(), children);
			n.setEndOf(node.getEndOf());

			return n;
		}

		if (count <= 5) {
			Node n = new ArrayNode(node.value(), children);
			n.setEndOf(node.getEndOf());

			return n;
		}

		// best left as a hash node
		return node;
	}

	/**
	 * Defines a node type.
	 */
	public static interface Node {
		/**
		 * Returns the child the has the given collation key.
		 * 
		 * @param word
		 *            word to search for
		 * 
		 * @return the node, or <code>null</code> if not found.
		 */
		public Node getChild(CollationKey word);

		/**
		 * Labels this node as the termination point for the phrase.
		 * 
		 * @param id
		 *            the ID of the phrase this terminates
		 */
		public void setEndOf(int id);

		/**
		 * Returns the phrase this node is the termination point for.
		 * 
		 * @return the phrase
		 */
		public int getEndOf();

		/**
		 * Check to see if this node is the termination point of a phrase.
		 * 
		 * @return true if this node is the termination point of a phrase
		 */
		public boolean isEndOf();

		/**
		 * Appends a child to this node; <b><i>Optional operation</i></b>.
		 * 
		 * @return the appended node
		 */
		public Node appendChild(String word);

		/**
		 * The value this node wraps.
		 * 
		 * @return the value
		 */
		public CollationKey value();
	}

	/**
	 * A node in the tree having a single child
	 */
	private abstract class AbstractNode implements Node {
		/** The word this node represents */
		protected final CollationKey value;

		/** hash code caching */
		private final int hash;

		/**
		 * Index of the phrase in the {@link AhoCorasickPhraseMatcher#find}array
		 * that this is the last word of.
		 */
		private int endOf = -1;

		/**
		 * Creates a new node
		 * 
		 * @param value
		 *            the value of the node.
		 */
		private AbstractNode(CollationKey value) {
			this.value = value;
			this.hash = (value == null) ? 0 : value.hashCode();
		}

		/**
		 * @see AhoCorasickTree.Node#setEndOf(int)
		 */
		public void setEndOf(int id) {
			if (id < 0)
				throw new IllegalArgumentException();
			if (endOf != -1)
				throw new IllegalStateException();
			this.endOf = id;
		}

		/**
		 * @see AhoCorasickTree.Node#getEndOf()
		 */
		public int getEndOf() {
			return endOf;
		}

		/**
		 * @see AhoCorasickTree.Node#isEndOf()
		 */
		public boolean isEndOf() {
			return (this.endOf >= 0);
		}

		/**
		 * Returns the hashcode of the value.
		 * 
		 * @return hashcode
		 */
		public int hashCode() {
			return this.hash;
		}

		/**
		 * @see AhoCorasickTree.Node#value()
		 */
		public CollationKey value() {
			return value;
		}
	}

	/**
	 * A node in the tree using an array for storage.
	 */
	private class ArrayNode extends AbstractNode {
		/** The children of this node. */
		private Node[] children;

		/**
		 * Creates a new node
		 * 
		 * @param value
		 *            the value of the node
		 */
		private ArrayNode(CollationKey value) {
			super(value);
			this.children = new Node[0];
		}

		/**
		 * Creates a new node
		 * 
		 * @param value
		 *            the value of the node
		 * @param children
		 *            the children of the node
		 */
		private ArrayNode(CollationKey value, Set<Node> children) {
			super(value);
			this.children = children.toArray(new Node[children.size()]);
		}

		/**
		 * @see AhoCorasickTree.Node#getChild(CollationKey)
		 */
		public Node getChild(CollationKey word) {
			int hash = word.hashCode();

			for (int i = 0; i < children.length; i++) {
				if ((hash == children[i].hashCode())
						&& children[i].value().equals(word)) {
					return children[i];
				}
			}

			return null;
		}

		/**
		 * @see AhoCorasickTree.Node#appendChild(String)
		 */
		public Node appendChild(String child) {
			if (child == null) {
				throw new NullPointerException("null words are not supported");
			}

			CollationKey word = collator.getCollationKey(child);

			// look for an existing node with this value
			Node node = getChild(word);

			if (node != null) {
				return node;
			}

			// a brood is a lot of children :)
			node = new ArrayNode(word);

			Node[] brood = new Node[children.length + 1];
			System.arraycopy(children, 0, brood, 0, children.length);
			brood[children.length] = node;
			children = brood;

			return node;
		}
	}

	/**
	 * A node in the tree using a hash structure for storage.
	 */
	private class HashNode extends AbstractNode {
		/** The children of this node. */
		private final HashMap<CollationKey, Node> children = new HashMap<CollationKey, Node>();

		/**
		 * Creates a new node
		 * 
		 * @param value
		 *            The value of the node
		 */
		private HashNode(CollationKey value) {
			super(value);
		}

		/**
		 * @see AhoCorasickTree.Node#getChild(CollationKey)
		 */
		public Node getChild(CollationKey word) {
			return (Node) children.get(word);
		}

		/**
		 * @see AhoCorasickTree.Node#appendChild(String)
		 */
		public Node appendChild(String child) {
			if (child == null) {
				throw new NullPointerException("null words are not supported");
			}

			CollationKey word = collator.getCollationKey(child);

			// look for an existing node with this value
			Node node = getChild(word);

			if (node == null) {
				// add
				node = new HashNode(word);
				children.put(node.value(), node);
			}

			return node;
		}
	}

	/**
	 * A node in the tree with no children
	 */
	private class NoChildNode extends AbstractNode {
		/**
		 * Creates a new NoChildNode object.
		 * 
		 * @param value
		 *            the value of the node
		 */
		NoChildNode(CollationKey value) {
			super(value);
		}

		/**
		 * @see AhoCorasickTree.Node#getChild(CollationKey)
		 */
		public Node getChild(CollationKey word) {
			return null;
		}

		/**
		 * @see AhoCorasickTree.Node#appendChild(String)
		 */
		public Node appendChild(String word) {
			throw new UnsupportedOperationException(
					"A SingleChildNode can have only one child");
		}
	}

	/**
	 * A node in the tree with a single child
	 */
	private class SingleChildNode extends AbstractNode {
		/** The child */
		final Node child;

		/**
		 * Creates a new SingleChildNode object.
		 * 
		 * @param value
		 *            the value of the enode
		 * @param child
		 *            the child of this node
		 * 
		 * @throws IllegalArgumentException
		 *             if the child set does not have one entry
		 */
		SingleChildNode(CollationKey value, Set child) {
			super(value);

			if (child.size() != 1) {
				throw new IllegalArgumentException(
						"A SingleChildNode can have only one child");
			}

			this.child = (Node) child.iterator().next();
		}

		/**
		 * @see AhoCorasickTree.Node#getChild(CollationKey)
		 */
		public Node getChild(CollationKey word) {
			if (child.value().equals(word)) {
				return child;
			}

			return null;
		}

		/**
		 * @see AhoCorasickTree.Node#appendChild(String)
		 */
		public Node appendChild(String word) {
			throw new UnsupportedOperationException(
					"A SingleChildNode can have only one child");
		}
	}

	/**
	 * Prints a node tree to stdout
	 */
	private static final class TestPrinter {
		static String PADDING = "                                                      ";

		/**
		 * print a node and its children
		 * 
		 * @param root
		 *            node
		 */
		private static void printGraph(Node root) {
			printGraph(root, 0);
		}

		/**
		 * Prints a node and it's children
		 * 
		 * @param node
		 *            node
		 * @param level
		 *            padding level
		 */
		private static void printGraph(Node node, int level) {
			if (node.value() == null) {
				printPadded("null", 4 * level);
			} else {
				printPadded(node.value().getSourceString(), 4 * level);
			}

			String name = node.getClass().getName().replaceFirst(".*\\$", "/");
			System.out.print(name);
			System.out.println(node.isEndOf() ? " END" : "");

			if (node instanceof HashNode) {
				HashNode n = (HashNode) node;

				for (Iterator i = n.children.values().iterator(); i.hasNext();) {
					printGraph((Node) i.next(), level + 1);
				}
			} else if (node instanceof ArrayNode) {
				ArrayNode arr = (ArrayNode) node;

				for (int i = 0; i < arr.children.length; i++) {
					printGraph(arr.children[i], level + 1);
				}
			} else if (node instanceof NoChildNode) {
				// no children to print
			} else if (node instanceof SingleChildNode) {
				SingleChildNode n = (SingleChildNode) node;
				printGraph(n.child, level + 1);
			} else if (node instanceof TwoChildNode) {
				TwoChildNode n = (TwoChildNode) node;
				printGraph(n.child1, level + 1);
				printGraph(n.child2, level + 1);
			} else {
				System.out.println("UNKNOWN TYPE: " + node.getClass());
			}
		}

		/**
		 * Print a string
		 * 
		 * @param str
		 *            the string
		 * @param padding
		 *            padding amount
		 */
		private static void printPadded(String str, int padding) {
			if (padding > PADDING.length()) {
				char[] p = new char[padding];
				Arrays.fill(p, ' ');
				PADDING = new String(p);
			}

			System.out.print(PADDING.substring(0, padding));
			System.out.print(str);
		}
	}

	/**
	 * A node in the tree with two children.
	 */
	private class TwoChildNode extends AbstractNode {
		/** First Child */
		final Node child1;

		/** Second Child */
		final Node child2;

		/**
		 * Creates a new TwoChildNode object.
		 * 
		 * @param value
		 *            the value of the node
		 * @param children
		 *            the children of the node
		 * 
		 * @throws IllegalArgumentException
		 *             if the children set does not have two nodes.
		 */
		TwoChildNode(CollationKey value, Set children) {
			super(value);

			if (children.size() != 2) {
				throw new IllegalArgumentException(
						"Only two children are supported");
			}

			Iterator i = children.iterator();
			this.child1 = (Node) i.next();
			;
			this.child2 = (Node) i.next();
			;
		}

		/**
		 * @see AhoCorasickTree.Node#getChild(CollationKey)
		 */
		public Node getChild(CollationKey word) {
			if (child1.value().equals(word)) {
				return child1;
			}

			if (child2.value().equals(word)) {
				return child2;
			}

			return null;
		}

		/**
		 * @see AhoCorasickTree.Node#appendChild(String)
		 */
		public Node appendChild(String word) {
			throw new UnsupportedOperationException(
					"A SingleChildNode can have only one child");
		}
	}
}
