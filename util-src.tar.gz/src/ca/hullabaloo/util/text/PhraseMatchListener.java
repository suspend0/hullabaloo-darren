package ca.hullabaloo.util.text;

/**
 * Interface for things that want to know when a match occurs
 */
public interface PhraseMatchListener {
	/**
	 * Signals a match was found. Note that
	 * <code> input.subSequence(start, start +
	 * length).equals(phrase) </code>
	 * will be <code>true</code> for all usual cases. However, if the matcher
	 * is not case sensitive it might not be equal -- some case transformations
	 * cause the string to grow or shrink. See
	 * {@link String#toLowerCase(java.util.Locale)}for details.
	 * 
	 * @param input
	 *            the input we matched against
	 * @param start
	 *            the starting character of the match in the input string
	 * @param length
	 *            the length of the match
	 * @param phrase
	 *            the phrase we found
	 * @param wordNumber
	 *            the index of the starting <b>word </b> in the input string
	 * @param wordCount
	 *            the number of words in the phrase in the effective locale
	 */
	public void matched(CharSequence input, int start, int length,
			CharSequence phrase, int wordNumber, int wordCount);
}
