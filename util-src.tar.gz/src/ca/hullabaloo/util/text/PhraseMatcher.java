package ca.hullabaloo.util.text;

/**
 * Matchers that matches phraes
 * 
 * @author darren
 */
public interface PhraseMatcher {
	/**
	 * Search the input for any of the search strings
	 * 
	 * @param input
	 *            The input string
	 * @param listener
	 *            signal when a phrase is matched
	 */
	public void match(String input, PhraseMatchListener listener);
}
