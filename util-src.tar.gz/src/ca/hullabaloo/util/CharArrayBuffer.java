package ca.hullabaloo.util;

/**
 * Much like a StringBuffer, except unsynchronized, gives access to the internal
 * (possibly transient) char array, doesn't support insert(), has a larger
 * default size, and throws a NullPointerException if you try to append a null
 * value.
 * 
 * @author Darren Gilroy
 */
public class CharArrayBuffer {
	/** chunk size */
	private static final int s_chunkSize = 512;

	/** the characters */
	private char[] m_value;

	/** the number of characters used */
	private int m_size;

	/**
	 * This no-arg constructor.
	 */
	public CharArrayBuffer() {
		m_value = new char[s_chunkSize];
	}

	/**
	 * Resets the number of characters in the buffer
	 * 
	 * @param newLength
	 *            the new length
	 * 
	 * @throws StringIndexOutOfBoundsException
	 *             if the new length is less than zero
	 */
	public void setLength(int newLength) {
		if (newLength < 0) {
			throw new StringIndexOutOfBoundsException(newLength);
		}

		if (newLength == 0) {
			if (m_value.length > s_chunkSize) {
				m_value = null;
				m_value = new char[s_chunkSize];
			}
		}

		if (newLength > m_value.length) {
			grow(newLength);
		}

		if (m_size < newLength) {
			for (; m_size < newLength; m_size++)
				m_value[m_size] = '\0';
		} else {
			m_size = newLength;
		}
	}

	/**
	 * Appends the data in the passed char array to the buffer
	 * 
	 * @param ch
	 *            the data to append
	 * 
	 * @return <code>this</code>
	 */
	public CharArrayBuffer append(char[] ch) {
		int newSize = m_size + ch.length;

		if (newSize > ch.length) {
			grow(newSize);
		}

		System.arraycopy(ch, 0, m_value, m_size, ch.length);
		m_size = newSize;

		return this;
	}

	/**
	 * Appends the data in the passed char array to the buffer
	 * 
	 * @param ch
	 *            the data to append
	 * @param start
	 *            the position in the start data to start
	 * @param len
	 *            the number of chars to append
	 * 
	 * @return <code>this</code>
	 */
	public CharArrayBuffer append(char[] ch, int start, int len) {
		int newSize = m_size + len;

		if (newSize > m_value.length) {
			grow(newSize);
		}

		System.arraycopy(ch, start, m_value, m_size, len);
		m_size = newSize;

		return this;
	}

	/**
	 * Appends the passed string to the buffer
	 * 
	 * @param str
	 *            the string to append
	 * 
	 * @return <code>this</code>
	 */
	public CharArrayBuffer append(String str) {
		int len = str.length();

		if (len > 0) {
			int newSize = m_size + len;

			if (newSize > m_value.length) {
				grow(newSize);
			}

			str.getChars(0, len, m_value, m_size);
			m_size = newSize;
		}

		return this;
	}

	/**
	 * This is the underlying array at the point-in-time you call this method.
	 * Do not store a reference to this, it could be replaced by a call to
	 * append() or setLength() or other methods which may modify the content of
	 * the buffer. Modifications to this array affect the source CharArrayBuffer
	 * for as long as the CharArrayBuffer is using this array. The application
	 * must take care to not modify positions greater than
	 * CharArrayBuffer.length().
	 * 
	 * <p>
	 * <b>Note </b> that <code>array().length</code> may not, and probably
	 * will not, equal <code>length()</code>
	 * </p>
	 * 
	 * @return the CharArrayBuffer's underlying character array.
	 */
	public char[] array() {
		return m_value;
	}

	/**
	 * Returns the first location of the character array matched
	 * 
	 * @param search
	 *            the string to search for
	 * 
	 * @return the found position.
	 */
	public int indexOf(char[] search) {
		return indexOf(search, 0);
	}

	/**
	 * Returns the first location of the character array matched after the
	 * specified index
	 * 
	 * @param search
	 *            the string to search for
	 * @param fromIndex
	 *            the position in the buffer to start the search
	 * 
	 * @return the position, or -1 if not found
	 */
	public int indexOf(char[] search, int fromIndex) {
		return indexOf(m_value, 0, m_size, search, 0, search.length, fromIndex);
	}

	/**
	 * This code is Copyright Sun Microsystems and distributed as part of
	 * java.lang.String
	 * 
	 * <p>
	 * Code shared by String and StringBuffer to do searches. The source is the
	 * character array being searched, and the target is the string being
	 * searched for.
	 * </p>
	 * 
	 * @param source
	 *            the characters being searched.
	 * @param sourceOffset
	 *            offset of the source string.
	 * @param sourceCount
	 *            count of the source string.
	 * @param target
	 *            the characters being searched for.
	 * @param targetOffset
	 *            offset of the target string.
	 * @param targetCount
	 *            count of the target string.
	 * @param fromIndex
	 *            the index to begin searching from.
	 * 
	 * @return found position, or -1 if not found
	 */
	public static int indexOf(char[] source, int sourceOffset, int sourceCount,
			char[] target, int targetOffset, int targetCount, int fromIndex) {
		if (fromIndex >= sourceCount) {
			return ((targetCount == 0) ? sourceCount : (-1));
		}

		if (fromIndex < 0) {
			fromIndex = 0;
		}

		if (targetCount == 0) {
			return fromIndex;
		}

		char first = target[targetOffset];
		int max = sourceOffset + (sourceCount - targetCount);

		for (int i = sourceOffset + fromIndex; i <= max; i++) {
			/* Look for first character. */
			if (source[i] != first) {
				while ((++i <= max) && (source[i] != first))
					;
			}

			/* Found first character, now look at the rest of v2 */
			if (i <= max) {
				int j = i + 1;
				int end = (j + targetCount) - 1;

				for (int k = targetOffset + 1; (j < end)
						&& (source[j] == target[k]); j++, k++)
					;

				if (j == end) {
					/* Found whole string. */
					return i - sourceOffset;
				}
			}
		}

		return -1;
	}

	/**
	 * Returns the number of characters in the buffer.
	 * 
	 * @return length
	 */
	public int length() {
		return m_size;
	}

	/**
	 * a string representation
	 * 
	 * @return the char array as a string.
	 */
	public String toString() {
		return new String(m_value, 0, m_size);
	}

	/**
	 * Expands the underlying character array to the passe size
	 * 
	 * @param minSize
	 *            the new minimum size
	 */
	private void grow(int minSize) {
		// find the next multiple of the chunk size greater than the minSize,
		// or double, whichever is greater
		int newSize = (minSize + s_chunkSize) - (minSize % s_chunkSize);
		newSize = Math.max(newSize, m_value.length * 2);

		// grow the array
		char[] newValue = new char[newSize];
		System.arraycopy(m_value, 0, newValue, 0, m_size);
		m_value = newValue;
	}
}
