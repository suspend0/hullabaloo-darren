package ca.hullabaloo.util.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * Abstract class to create simple ElementSelector -- one which just checks tag
 * name &amp; attributes. This must be in the XMLFilter chain <b>before </b> any
 * filters that use the selector.
 * 
 * <p>
 * <b>Note: </b> This is an XMLFilter and should be in the filter pipeline
 * <i>before </i> any other filters that depend on it. Normally, that means
 * first.
 * </p>
 * 
 * @author Darren Gilroy
 */
public abstract class SaxSimpleElementSelector extends XMLFilterImpl implements
		SaxElementSelector {
	/** Enabled flag (this is what we actually use) */
	private boolean m_enabled = true;

	/**
	 * Enabled flag (this is set by {@link #disable()}, but only takes effect
	 * once we exit our selected tag)
	 */
	private boolean m_enabledFlag = true;

	/**
	 * This flag is used to ensure that this element selector is in the sax
	 * chain before it's used
	 */
	private boolean m_sawStartDocument = false;

	/** The selection state */
	private boolean m_startFlag = false;

	/** The level we're nested inside the document. */
	private int m_depth = 0;

	/** The level we're nested inside a selected element. */
	private int m_tagLevel = 0;

	/**
	 * @see SaxElementSelector#isEndElement()
	 */
	public boolean isEndElement() {
		if (!m_sawStartDocument) {
			didNotSeeStartDocumentException("isEndElement()");
		}

		return ((m_tagLevel == 1) && !m_startFlag);
	}

	/**
	 * @see ElementSelector#isSelected()
	 */
	public boolean isSelected() {
		if (!m_sawStartDocument) {
			didNotSeeStartDocumentException("isSelected()");
		}

		return (m_tagLevel > 0);
	}

	/**
	 * @see SaxElementSelector#isStartElement()
	 */
	public boolean isStartElement() {
		if (!m_sawStartDocument) {
			didNotSeeStartDocumentException("isStartElement()");
		}

		return ((m_tagLevel == 1) && m_startFlag);
	}

	/**
	 * The depth we are in the document tree
	 * 
	 * @return depth
	 */
	public int depth() {
		return m_depth;
	}

	/**
	 * Disable selection of any further elements, helpful when looking for the
	 * first instance of a cell. Does also provide some performance improvment
	 * on large documents if your match is towards the beginning
	 */
	public void disable() {
		m_enabledFlag = false;

		if (m_tagLevel == 0) {
			m_enabled = false;
		}
	}

	/**
	 * @see org.xml.sax.helpers.XMLFilterImpl#endDocument()
	 */
	public void endDocument() throws SAXException {
		m_sawStartDocument = false;
		super.endDocument();
	}

	/**
	 * @see XMLFilterImpl#endElement(java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		super.endElement(uri, localName, qName);

		m_depth--;

		if (m_enabled) {
			if (!(m_enabledFlag) && (m_tagLevel == 1)) {
				m_enabled = false;
			}

			if (m_tagLevel > 0) {
				--m_tagLevel;
			}
		}
	}

	/**
	 * @see org.xml.sax.helpers.XMLFilterImpl#startDocument()
	 */
	public void startDocument() throws SAXException {
		m_sawStartDocument = true;
		m_tagLevel = 0;
		m_depth = 0;
		super.startDocument();
	}

	/**
	 * @see XMLFilterImpl#startElement(java.lang.String, java.lang.String,
	 *      java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		m_depth++;

		if (m_enabled) {
			// if we're not already in a tag, check to see if we should be in a
			// tag
			if (m_tagLevel == 0) {
				if (selectElement(uri, localName, qName, atts)) {
					m_tagLevel = 1;
					m_startFlag = true;
				}
			} else {
				m_tagLevel++;
			}
		}

		super.startElement(uri, localName, qName, atts);

		m_startFlag = false;
	}

	/**
	 * If this method returns true, the isSelected() tag will return true until
	 * this element ends. This method is called only when isSelected() is false.
	 * 
	 * @param uri
	 *            the namespace uri
	 * @param localName
	 *            the localName
	 * @param qName
	 *            the qualified name
	 * @param atts
	 *            the attributes
	 * 
	 * @return true on matching elements
	 */
	protected abstract boolean selectElement(String uri, String localName,
			String qName, Attributes atts);

	/**
	 * Throws an exception
	 * 
	 * @param method
	 *            the method that called this one
	 * 
	 * @throws IllegalStateException
	 *             always
	 */
	private void didNotSeeStartDocumentException(String method) {
		throw new IllegalStateException(
				"This class must be in the SAX event stream.  "
						+ "It is an error for the '"
						+ method
						+ "' method to be called before ContentHandler#startDocument()");
	}
}
