package ca.hullabaloo.util.sax;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

/**
 * Factory for new content handlers.
 * 
 * @author Darren Gilroy
 */
public interface ContentHandlerFactory {
    /**
     * Returns a new content handler.
     * 
     * @return content handler
     */
    ContentHandler getContentHandler() throws SAXException;
}
