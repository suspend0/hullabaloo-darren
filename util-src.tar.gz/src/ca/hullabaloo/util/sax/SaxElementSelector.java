package ca.hullabaloo.util.sax;

/**
 * Interface to encapsulate element selection to ease the writing of
 * {@link org.xml.sax.XMLFilter}s
 * 
 * @author Darren Gilroy
 */
public interface SaxElementSelector extends ElementSelector {
	/**
	 * Returns true if we are in the end element of a selector.
	 * 
	 * @return true/false
	 */
	public boolean isEndElement();

	/**
	 * Returns true if we are in the start element of a selector.
	 * 
	 * @return true/false
	 */
	public boolean isStartElement();

	/**
	 * Call to disable further selection by this selector.
	 */
	public void disable();
}
