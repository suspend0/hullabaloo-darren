package ca.hullabaloo.util.sax;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Content Handler that passes the events it receives to a parent content
 * handler.
 * 
 * @author Darren Gilroy
 */
public class ProxyContentHandler implements ContentHandler {
	/** the one we send our events too */
	private ContentHandler m_parent;

	/** Locator for parse exceptions */
	private Locator m_locator;

	/**
	 * Creates a new ProxyContentHandler object.
	 * 
	 * @param handler
	 *            The parent content handler to send non-transform elements too
	 */
	public ProxyContentHandler(ContentHandler handler) {
		// handler
		setParent(handler);
	}

	/**
	 * Creates a new ProxyContentHandler object.
	 */
	public ProxyContentHandler() {
	}

	/**
	 * save my locator so I can throw my own exceptions, and then proxies this
	 * call to the parent content handler
	 * 
	 * @param locator
	 *            {@link ContentHandler}
	 */
	public void setDocumentLocator(Locator locator) {
		m_locator = locator;
		m_parent.setDocumentLocator(locator);
	}

	/**
	 * Returns the document locator so you can create your own
	 * SAXParseExceptions
	 * 
	 * @see #parseException(String)
	 */
	public Locator getDocumentLocator() {
		return m_locator;
	}

	/**
	 * sets the parenet content handler
	 * 
	 * @param ch
	 *            the new parent
	 */
	public void setParent(ContentHandler ch) {
		m_parent = ch;
	}

	/**
	 * gets the parent content handler
	 * 
	 * @return Content Handler
	 */
	public ContentHandler getParent() {
		return m_parent;
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @param ch
	 *            See {@link ContentHandler}
	 * @param start
	 *            See {@link ContentHandler}
	 * @param length
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		m_parent.characters(ch, start, length);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void endDocument() throws SAXException {
		m_parent.endDocument();
		m_locator = null;
	}

	/**
	 * Proxies to the parent ContentHandler.
	 * 
	 * @param uri
	 *            See {@link ContentHandler}
	 * @param localName
	 *            See {@link ContentHandler}
	 * @param qName
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		m_parent.endElement(uri, localName, qName);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @param prefix
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void endPrefixMapping(String prefix) throws SAXException {
		m_parent.endPrefixMapping(prefix);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @param ch
	 *            See {@link ContentHandler}
	 * @param start
	 *            See {@link ContentHandler}
	 * @param length
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
		m_parent.ignorableWhitespace(ch, start, length);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @param target
	 *            {@link ContentHandler}
	 * @param data
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void processingInstruction(String target, String data)
			throws SAXException {
		m_parent.processingInstruction(target, data);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @param name
	 *            {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void skippedEntity(String name) throws SAXException {
		m_parent.skippedEntity(name);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void startDocument() throws SAXException {
		// Locator for parse exceptions
		m_locator = null;

		m_parent.startDocument();
	}

	/**
	 * Detects the start of a <code>fbf:Transform</code> element, or proxies
	 * to the parent ContentHandler
	 * 
	 * @param uri
	 *            See {@link ContentHandler}
	 * @param localName
	 *            See {@link ContentHandler}
	 * @param qName
	 *            See {@link ContentHandler}
	 * @param atts
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		m_parent.startElement(uri, localName, qName, atts);
	}

	/**
	 * Proxies this call to the parent content handler
	 * 
	 * @param prefix
	 *            See {@link ContentHandler}
	 * @param uri
	 *            See {@link ContentHandler}
	 * 
	 * @throws SAXException
	 *             See {@link ContentHandler}
	 */
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		m_parent.startPrefixMapping(prefix, uri);
	}

	/**
	 * Throws a parse exception
	 * 
	 * @param message
	 *            the exception message
	 * 
	 * @throws SAXParseException
	 *             always!
	 */
	protected void parseException(String message) throws SAXParseException {
		throw new SAXParseException(message, m_locator);
	}

	/**
	 * Throws a parse exception
	 * 
	 * @param message
	 *            the exception message
	 * @param cause
	 *            root cause
	 * 
	 * @throws SAXParseException
	 *             always!
	 */
	protected void parseException(String message, Exception cause)
			throws SAXParseException {
		throw new SAXParseException(message, m_locator, cause);
	}
}
