package ca.hullabaloo.util.sax;

import java.io.IOException;

import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLFilter;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Provides an easy way to build a chain of {@link org.xml.sax.XMLFilter}s.
 * This does not implement XMLFilter, because I can't think of a clean way to do
 * it -- does getParent() changes after every append??
 * 
 * @author Darren Gilroy
 */
public class XMLFilterChain implements XMLReader {
	/** The last filter in our chain. */
	private XMLReader tail;

	/**
	 * Creates a filter chain with the passed XMLReader at its head
	 * 
	 * @param reader
	 *            The head of the chain
	 */
	public XMLFilterChain(XMLReader reader) {
		tail = reader;
	}

	/**
	 * Creates a filter chain with an XMLReader at its head
	 * 
	 * @throws SAXException
	 *             if a reader cannot be created
	 */
	public XMLFilterChain() throws SAXException {
		this(XMLReaderFactory.createXMLReader());
	}

	/**
	 * @see org.xml.sax.XMLReader#setContentHandler(org.xml.sax.ContentHandler)
	 */
	public void setContentHandler(ContentHandler handler) {
		tail.setContentHandler(handler);
	}

	/**
	 * @see org.xml.sax.XMLReader#getContentHandler()
	 */
	public ContentHandler getContentHandler() {
		return tail.getContentHandler();
	}

	/**
	 * @see org.xml.sax.XMLReader#setDTDHandler(org.xml.sax.DTDHandler)
	 */
	public void setDTDHandler(DTDHandler handler) {
		tail.setDTDHandler(handler);
	}

	/**
	 * @see org.xml.sax.XMLReader#getDTDHandler()
	 */
	public DTDHandler getDTDHandler() {
		return tail.getDTDHandler();
	}

	/**
	 * @see org.xml.sax.XMLReader#setEntityResolver(org.xml.sax.EntityResolver)
	 */
	public void setEntityResolver(EntityResolver resolver) {
		tail.setEntityResolver(resolver);
	}

	/**
	 * @see org.xml.sax.XMLReader#getEntityResolver()
	 */
	public EntityResolver getEntityResolver() {
		return tail.getEntityResolver();
	}

	/**
	 * @see org.xml.sax.XMLReader#setErrorHandler(org.xml.sax.ErrorHandler)
	 */
	public void setErrorHandler(ErrorHandler handler) {
		tail.setErrorHandler(handler);
	}

	/**
	 * @see org.xml.sax.XMLReader#getErrorHandler()
	 */
	public ErrorHandler getErrorHandler() {
		return tail.getErrorHandler();
	}

	/**
	 * @see org.xml.sax.XMLReader#setFeature(java.lang.String, boolean)
	 */
	public void setFeature(String name, boolean value)
			throws SAXNotRecognizedException, SAXNotSupportedException {
		tail.setFeature(name, value);
	}

	/**
	 * @see org.xml.sax.XMLReader#getFeature(java.lang.String)
	 */
	public boolean getFeature(String name) throws SAXNotRecognizedException,
			SAXNotSupportedException {
		return tail.getFeature(name);
	}

	/**
	 * @see org.xml.sax.XMLReader#setProperty(java.lang.String,
	 *      java.lang.Object)
	 */
	public void setProperty(String name, Object value)
			throws SAXNotRecognizedException, SAXNotSupportedException {
		tail.setProperty(name, value);
	}

	/**
	 * @see org.xml.sax.XMLReader#getProperty(java.lang.String)
	 */
	public Object getProperty(String name) throws SAXNotRecognizedException,
			SAXNotSupportedException {
		return tail.getProperty(name);
	}

	/**
	 * Append a filter to the end of chain
	 * 
	 * @param filter
	 *            the filter
	 */
	public void append(XMLFilter filter) {
		filter.setParent(tail);
		tail = filter;
	}

	/**
	 * @see org.xml.sax.XMLReader#parse(org.xml.sax.InputSource)
	 */
	public void parse(InputSource input) throws IOException, SAXException {
		tail.parse(input);
	}

	/**
	 * @see org.xml.sax.XMLReader#parse(java.lang.String)
	 */
	public void parse(String systemId) throws IOException, SAXException {
		tail.parse(systemId);
	}
}
