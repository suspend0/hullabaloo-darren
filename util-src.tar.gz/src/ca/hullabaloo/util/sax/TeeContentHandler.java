package ca.hullabaloo.util.sax;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

/**
 * Duplicates content handler events to two content handlers.
 * 
 * @author Darren Gilroy
 */
public class TeeContentHandler implements ContentHandler {
	protected final ContentHandler ch;

	protected final ContentHandler branch;

	public TeeContentHandler(ContentHandler ch, ContentHandler branch) {
		this.ch = ch;
		this.branch = branch;
	}

	public void characters(char[] ch, int start, int length)
			throws SAXException {
		this.ch.characters(ch, start, length);
		this.branch.characters(ch, start, length);
	}

	public void endDocument() throws SAXException {
		this.ch.endDocument();
		this.branch.endDocument();
	}

	public void endElement(String namespace, String localName, String qName)
			throws SAXException {
		this.ch.endElement(namespace, localName, qName);
		this.branch.endElement(namespace, localName, qName);
	}

	public void endPrefixMapping(String prefix) throws SAXException {
		this.ch.endPrefixMapping(prefix);
		this.branch.endPrefixMapping(prefix);
	}

	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
		this.ch.ignorableWhitespace(ch, start, length);
		this.branch.ignorableWhitespace(ch, start, length);
	}

	public void processingInstruction(String target, String data)
			throws SAXException {
		this.ch.processingInstruction(target, data);
		this.branch.processingInstruction(target, data);
	}

	public void setDocumentLocator(Locator locator) {
		this.ch.setDocumentLocator(locator);
		this.branch.setDocumentLocator(locator);
	}

	public void skippedEntity(String name) throws SAXException {
		this.ch.skippedEntity(name);
		this.branch.skippedEntity(name);
	}

	public void startDocument() throws SAXException {
		this.ch.startDocument();
		this.branch.startDocument();
	}

	public void startElement(String namespace, String localname, String qName,
			Attributes atts) throws SAXException {
		this.ch.startElement(namespace, localname, qName, atts);
		this.branch.startElement(namespace, localname, qName, atts);
	}

	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		this.ch.startPrefixMapping(prefix, uri);
		this.branch.startPrefixMapping(prefix, uri);
	}

}
