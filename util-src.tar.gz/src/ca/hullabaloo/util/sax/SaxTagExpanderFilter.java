package ca.hullabaloo.util.sax;

import java.nio.CharBuffer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.XMLFilterImpl;

import ca.hullabaloo.util.CharArrayBuffer;

/**
 * Converts escaped tags-escaped-in-text into real elements.  This is a 
 * pretty limited implementation right now, for example empty tags are
 * not supported.  Use with care.
 * 
 * <p>
 * This class is reusable, but not thread safe.
 * </p>
 * 
 * <p>
 * <b>NOTE:</b> This only works across a single
 * {@link ContentHandler#characters(char[], int, int)} call, so it should be
 * prefaced with a {@link
 * com.fujitsu.fbf.fbf2.util.sax.SaxCharacterConsolidationFilter}.
 * </p>
 * 
 * @author Darren Gilroy
 */
public class SaxTagExpanderFilter extends XMLFilterImpl {
	/** Pattern to extract a node's attributes */
	private static final Pattern ATTRIBUTES_PATTERN = Pattern
			.compile(" ([a-zA-Z0-9_-]+)=\"(.*?)\"");

	/** empty attributes for sax */
	private static final Attributes EMPTY_ATTS = new AttributesImpl();

	/** If we should process this tag */
	private final ElementSelector m_selector;

	/** the current content we want to parse */
	private CharArrayBuffer m_buf = new CharArrayBuffer();

	/** the processor */
	private Processor m_processor = null;

	/**
	 * Creates a new AbstractSaxTagExpander that expands escaped tags of
	 * <code>tagName</code>
	 * 
	 * @param parent
	 *            the parent xml reader
	 * @param selector
	 *            only processes text when {@link ElementSelector#isSelected()}
	 *            is true.
	 */
	protected SaxTagExpanderFilter(XMLReader parent, ElementSelector selector) {
		super(parent);
		m_selector = selector;
	}

	/**
	 * Creates a new AbstractSaxTagExpander that expands escaped tags of
	 * <code>tagName</code>
	 * 
	 * @param selector
	 *            only processes text when {@link ElementSelector#isSelected()}
	 *            is true.
	 */
	protected SaxTagExpanderFilter(ElementSelector selector) {
		super();
		m_selector = selector;
	}

	/**
	 * Sets the tag we are expanding. This is for simple tags which do not have
	 * attributes.
	 * 
	 * @param tagName
	 *            the tag name (no angle braces, case sensitive)
	 */
	public void setTag(String tagName) {
		m_processor = new SimpleTagProcessor(tagName);
	}

	/**
	 * Sets the tag we are expanding. This is for tags which may have
	 * attributes. Properly-formattted attributes (name and value with
	 * double-quoted values) are copied to the new element, others are silently
	 * dropped.
	 * 
	 * @param tagName
	 *            the tag name (no angle braces, case sensitive)
	 */
	public void setTagWithAttributes(String tagName) {
		m_processor = new AttributeTagProcessor(tagName);
	}

	/**
	 * @see org.xml.sax.ContentHandler#characters(char[], int, int)
	 */
	public final void characters(char[] ch, int start, int length)
			throws SAXException {
		if (m_selector.isSelected()) {
			m_buf.append(ch, start, length);
		} else {
			super.characters(ch, start, length);
		}
	}

	/**
	 * @see org.xml.sax.ContentHandler#endElement(String, String, String)
	 */
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (m_selector.isSelected()) {
			// send events
			m_processor.process();
			m_buf.setLength(0);
		}

		super.endElement(uri, localName, qName);
	}

	/**
	 * Resets internal state before processing.
	 * 
	 * @throws SAXException
	 *             per api
	 */
	public void startDocument() throws SAXException {
		if (m_processor == null) {
			throw new SAXException("Must call setTag() before using");
		}

		m_buf.setLength(0);
		super.startDocument();
	}

	/**
	 * @see org.xml.sax.ContentHandler#startElement(java.lang.String,
	 *      java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	public final void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		if (m_selector.isSelected()) {
			// send events
			m_processor.process();
			m_buf.setLength(0);
		}

		super.startElement(uri, localName, qName, atts);
	}

	/**
	 * Adds an attribute to an Attributes object.
	 * 
	 * @param atts
	 *            The attributes object to add to
	 * @param name
	 *            the attribute name
	 * @param value
	 *            the attribute value
	 */
	private static void addAttribute(AttributesImpl atts, String name,
			String value) {
		atts.addAttribute("", name, name, "CDATA", value);
	}

	/**
	 * Interface for the object that processes our string data into SAX events.
	 */
	private interface Processor {
		/**
		 * Processes the string data.
		 * 
		 * @throws SAXException
		 *             per api
		 */
		public void process() throws SAXException;
	}

	/**
	 * Uses a combination of simple search and regular expressions to extract
	 * tags with attributes into SAX events.
	 */
	private class AttributeTagProcessor implements Processor {
		/** the name of the tag we're processing */
		private String m_tagName;

		/** character array with the partial begin tag */
		private char[] m_beginTag;

		/** character array with the full end tag */
		private char[] m_endTag;

		private char[] m_lt = { '>' };

		/**
		 * Creates a new AttributeTagProcessor object.
		 * 
		 * @param tagName
		 *            the tag name (case sensitive, no angle braces)
		 */
		private AttributeTagProcessor(String tagName) {
			m_tagName = tagName;
			m_beginTag = ('<' + m_tagName + ' ').toCharArray();
			m_endTag = ("</" + m_tagName + '>').toCharArray();
		}

		/**
		 * {@inheritDoc}
		 */
		public final void process() throws SAXException {
			if (m_buf.indexOf(m_beginTag) == -1) {
				SaxTagExpanderFilter.super.characters(m_buf.array(), 0, m_buf
						.length());
			} else {
				int start = 0;
				int length = m_buf.length();
				char[] ch = m_buf.array();
				Matcher m = ATTRIBUTES_PATTERN.matcher(CharBuffer.wrap(ch));
				AttributesImpl atts = null;

				while (start < length) {
					int beginTagPos = m_buf.indexOf(m_beginTag, start);

					if (beginTagPos == -1) {
						SaxTagExpanderFilter.super.characters(ch, start, length
								- start);

						return;
					}

					int beginTagEndPos = m_buf.indexOf(m_lt) + 1;
					int endTagPos = m_buf.indexOf(m_endTag, beginTagEndPos);

					if ((endTagPos > beginTagPos)
							&& (beginTagEndPos > beginTagPos)) {
						// extract attributes
						if (m.find(beginTagPos) && (m.end() <= beginTagEndPos)) {
							atts = new AttributesImpl();

							do {
								addAttribute(atts, m.group(1), m.group(2));
							} while ((m.end() < beginTagEndPos) && m.find());
						}

						// send chars
						SaxTagExpanderFilter.super.characters(ch, start,
								beginTagPos - start);
						SaxTagExpanderFilter.super
								.startElement("", m_tagName, m_tagName,
										((atts == null) ? EMPTY_ATTS : atts));
						SaxTagExpanderFilter.super.characters(ch,
								beginTagEndPos, endTagPos - beginTagEndPos);
						SaxTagExpanderFilter.super.endElement("", m_tagName,
								m_tagName);
						start = endTagPos + m_endTag.length;
					} else {
						SaxTagExpanderFilter.super.characters(ch, start, length
								- start);
					}
				}
			}
		}
	}

	/**
	 * Does a simple search and replace algorithm for simple tags.
	 */
	private class SimpleTagProcessor implements Processor {
		/** the name of the tag we're processing */
		private String m_tagName;

		/** character array with the full begin tag */
		private char[] m_beginTag;

		/** character array with the full end tag */
		private char[] m_endTag;

		/**
		 * Creates a new SimpleTagProcessor object.
		 * 
		 * @param tagName
		 *            the tag name (case sensitive, no angle braces)
		 */
		private SimpleTagProcessor(String tagName) {
			m_tagName = tagName;
			m_beginTag = ('<' + m_tagName + '>').toCharArray();
			m_endTag = ("</" + m_tagName + '>').toCharArray();
		}

		/**
		 * {@inheritDoc}
		 */
		public final void process() throws SAXException {
			int start = 0;
			int length = m_buf.length();
			char[] ch = m_buf.array();

			while (start < length) {
				int beginTagPos = m_buf.indexOf(m_beginTag, start);

				if (beginTagPos == -1) {
					SaxTagExpanderFilter.super.characters(ch, start, length
							- start);

					return;
				}

				int beginTagEndPos = beginTagPos + m_beginTag.length;
				int endTagPos = m_buf.indexOf(m_endTag, beginTagEndPos);

				if (endTagPos > beginTagPos) {
					SaxTagExpanderFilter.super.characters(ch, start,
							beginTagPos - start);
					SaxTagExpanderFilter.super.startElement("", m_tagName,
							m_tagName, EMPTY_ATTS);
					SaxTagExpanderFilter.super.characters(ch, beginTagEndPos,
							endTagPos - beginTagEndPos);
					SaxTagExpanderFilter.super.endElement("", m_tagName,
							m_tagName);
					start = endTagPos + m_endTag.length;
				} else {
					SaxTagExpanderFilter.super.characters(ch, start, length
							- start);
				}
			}
		}
	}
}
