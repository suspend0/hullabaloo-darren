package ca.hullabaloo.util.sax;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

import ca.hullabaloo.util.CharArrayBuffer;

/**
 * Consolidates consecutive {@link XMLFilterImpl#characters(char[],int,int)}
 * into a single characters call. This easing writing of filters which further
 * process the text.
 * 
 * @author Darren Gilroy
 */
public class SaxCharacterConsolidationFilter extends XMLFilterImpl {
	/** the current content we want to parse */
	private final CharArrayBuffer m_buf = new CharArrayBuffer();

	/** which nodes to consolidate character events for */
	private final ElementSelector m_selector;

	/**
	 * Creates a new AbstractSaxTagExpander that expands escaped tags of
	 * <code>tagName</code>
	 * 
	 * @param selector
	 *            only processes text when {@link ElementSelector#isSelected()}
	 *            is true.
	 */
	public SaxCharacterConsolidationFilter(ElementSelector selector) {
		super();
		m_selector = selector;
	}

	/**
	 * @see ContentHandler
	 */
	public final void characters(char[] ch, int start, int length)
			throws SAXException {
		if (m_selector.isSelected()) {
			m_buf.append(ch, start, length);
		} else {
			super.characters(ch, start, length);
		}
	}

	/**
	 * @see ContentHandler
	 */
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (m_selector.isSelected()) {
			sendBuffer();
		}

		super.endElement(uri, localName, qName);
	}

	/**
	 * Resets internal state.
	 * 
	 * @throws SAXException
	 *             per api
	 */
	public void startDocument() throws SAXException {
		m_buf.setLength(0);
		super.startDocument();
	}

	/**
	 * @see org.xml.sax.ContentHandler#startElement(java.lang.String,
	 *      java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	public final void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		if (m_selector.isSelected()) {
			sendBuffer();
		}

		super.startElement(uri, localName, qName, atts);
	}

	/**
	 * Sends the buffer as a single character event.
	 * 
	 * @throws SAXException
	 *             per api
	 */
	private void sendBuffer() throws SAXException {
		int len = m_buf.length();

		if (len > 0) {
			super.characters(m_buf.array(), 0, len);
			m_buf.setLength(0);
		}
	}
}
