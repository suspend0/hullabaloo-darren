package ca.hullabaloo.util.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * Removes selected elements from the sax stream. It blocks the content handler
 * events when isSelected is true. Calling includeWhenSelected() reverses this
 * behaviour. See also removeWhenSelected();
 * 
 * @author Darren Gilroy
 */
public class SaxElementFilter extends XMLFilterImpl {
	/** chooses elements to work on */
	private final ElementSelector m_selector;

	/** The mode we are working */
	private boolean include = false;

	/**
	 * Creates a new SaxRemoveElementFilter
	 * 
	 * @param parent
	 *            the parent XMLReader
	 * @param selector
	 *            blocks ContentHandler calls when
	 *            {@link ElementSelector#isSelected()} is true.
	 */
	public SaxElementFilter(XMLReader parent, ElementSelector selector) {
		super(parent);
		m_selector = selector;
	}

	/**
	 * Creates a new SaxRemoveElementFilter
	 * 
	 * @param selector
	 *            blocks ContentHandler calls when
	 *            {@link ElementSelector#isSelected()} is true.
	 */
	public SaxElementFilter(ElementSelector selector) {
		super();
		m_selector = selector;
	}

	/**
	 * @see XMLFilterImpl#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int len) throws SAXException {
		if (include == m_selector.isSelected()) {
			super.characters(ch, start, len);
		}
	}

	/**
	 * @see XMLFilterImpl#endElement(java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void endElement(String namespace, String localName, String qName)
			throws SAXException {
		if (include == m_selector.isSelected()) {
			super.endElement(namespace, localName, qName);
		}
	}

	/**
	 * @see XMLFilterImpl#endPrefixMapping(java.lang.String)
	 */
	public void endPrefixMapping(String prefix) throws SAXException {
		if (include == m_selector.isSelected()) {
			super.endPrefixMapping(prefix);
		}
	}

	/**
	 * @see XMLFilterImpl#ignorableWhitespace(char[], int, int)
	 */
	public void ignorableWhitespace(char[] ch, int start, int len)
			throws SAXException {
		if (include == m_selector.isSelected()) {
			super.ignorableWhitespace(ch, start, len);
		}
	}

	/**
	 * Instructs this filter to only include elements when isSelected() is true
	 * 
	 * @return this object
	 */
	public SaxElementFilter includeWhenSelected() {
		include = true;

		return this;
	}

	/**
	 * @see XMLFilterImpl#processingInstruction(java.lang.String,
	 *      java.lang.String)
	 */
	public void processingInstruction(String target, String data)
			throws SAXException {
		if (include == m_selector.isSelected()) {
			super.processingInstruction(target, data);
		}
	}

	/**
	 * Instructs this filter to remove elements from the sax stream when
	 * isSelected() is true (Default Behaviour).
	 * 
	 * @return this object
	 */
	public SaxElementFilter removeWhenSelected() {
		include = false;

		return this;
	}

	/**
	 * @see XMLFilterImpl#skippedEntity(java.lang.String)
	 */
	public void skippedEntity(String entity) throws SAXException {
		if (include == m_selector.isSelected()) {
			super.skippedEntity(entity);
		}
	}

	/**
	 * @see XMLFilterImpl#startElement(java.lang.String, java.lang.String,
	 *      java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String namespace, String localName, String qName,
			Attributes atts) throws SAXException {
		if (include == m_selector.isSelected()) {
			super.startElement(namespace, localName, qName, atts);
		}
	}

	/**
	 * @see XMLFilterImpl#startPrefixMapping(java.lang.String, java.lang.String)
	 */
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		if (include == m_selector.isSelected()) {
			super.startPrefixMapping(prefix, uri);
		}
	}
}
