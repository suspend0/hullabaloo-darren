package ca.hullabaloo.util.sax;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import javax.xml.transform.sax.SAXSource;

import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;

/**
 * Allows you to use a SaxBuffer as a JAXP Source object
 * 
 * @author Darren Gilroy
 */
public class SaxBufferSource extends SAXSource {

	/**
	 * Creates a new SaxBufferSource object.
	 * 
	 * @param systemId
	 *            The system id of the source
	 * @param buf
	 *            the data for the source
	 */
	public SaxBufferSource(String systemId, SaxBuffer buf) {
		super();
		super.setXMLReader(createReader());
		super.setInputSource(createInputSource(systemId, buf));
	}

	/**
	 * Returns a reader for this thread
	 * 
	 * @return a reader for the SAXSource
	 */
	protected XMLReader createReader() {
		return new SaxBufferReader();
	}

	protected InputSource createInputSource(String systemId, SaxBuffer buf) {
		return new SaxBufferInputSource(systemId, buf);
	}

	/**
	 * Wraps a SaxBuffer as a SAX InputSource.
	 */
	private static class SaxBufferInputSource extends InputSource {
		private SaxBuffer m_buf;

		/**
		 * Creates a new SaxBufferInputSource object.
		 * 
		 * @param systemId
		 *            the system id
		 * @param saxBuffer
		 *            the buffer data
		 */
		private SaxBufferInputSource(String systemId, SaxBuffer saxBuffer) {
			m_buf = saxBuffer;
			setSystemId(systemId);
		}

		/**
		 * Unsupported
		 * 
		 * @param arg0
		 * 
		 * @throws UnsupportedOperationException
		 *             always
		 */
		public void setByteStream(InputStream arg0) {
			throw new UnsupportedOperationException();
		}

		/**
		 * Unsupported
		 * 
		 * @param arg0
		 * 
		 * @throws UnsupportedOperationException
		 *             always
		 */
		public void setCharacterStream(Reader arg0) {
			throw new UnsupportedOperationException();
		}

		/**
		 * Unsupported
		 * 
		 * @param arg0
		 * 
		 * @throws UnsupportedOperationException
		 *             always
		 */
		public void setEncoding(String arg0) {
			throw new UnsupportedOperationException();
		}
	}

	/**
	 * XMLReader for a {@link SaxBufferSource.SaxBufferReader}
	 */
	private static class SaxBufferReader implements XMLReader {
		private EntityResolver entityResolver;

		private ContentHandler contentHandler;

		private DTDHandler dtdHandler;

		private ErrorHandler errorHandler;

		/**
		 * Throws a UnsupportedOperationException.
		 * 
		 * @param systemId
		 *            ignored
		 * 
		 * @throws IOException
		 *             never
		 * @throws SAXException
		 *             never
		 * @throws UnsupportedOperationException
		 *             always
		 */
		public void parse(String systemId) throws IOException, SAXException {
			throw new UnsupportedOperationException(
					"Must use parse(InputSource)");
		}

		/**
		 * Parses a SaxBufferInputSource.
		 * 
		 * @param is
		 *            a SaxBufferInputSource
		 * 
		 * @throws IOException
		 *             on error
		 * @throws SAXException
		 *             on error
		 * @throws SAXNotSupportedException
		 *             if not a SaxBufferInputSource
		 */
		public void parse(InputSource is) throws IOException, SAXException {
			if (is instanceof SaxBufferInputSource) {
				SaxBuffer buf = ((SaxBufferInputSource) is).m_buf;
				buf.toSAX(this.contentHandler);
			} else {
				throw new SAXNotSupportedException(
						"Must be a SaxBufferInputSource");
			}
		}

		public boolean getFeature(String feature)
				throws SAXNotRecognizedException, SAXNotSupportedException {
			if (feature == null)
				return false;
			if (feature.equals("http://xml.org/sax/features/namespaces"))
				return true;
			if (feature
					.equals("http://xml.org/sax/features/namespace-prefixes"))
				return true;
			return false;
		}

		public void setFeature(String feature, boolean value)
				throws SAXNotRecognizedException, SAXNotSupportedException {
			if (feature == null)
				throw new SAXNotRecognizedException();
			if (feature.equals("http://xml.org/sax/features/namespaces"))
				return;
			if (feature
					.equals("http://xml.org/sax/features/namespace-prefixes"))
				return;
			throw new SAXNotRecognizedException();
		}

		public Object getProperty(String propery)
				throws SAXNotRecognizedException, SAXNotSupportedException {
			return null;
		}

		public void setProperty(String arg0, Object arg1)
				throws SAXNotRecognizedException, SAXNotSupportedException {
		}

		public void setEntityResolver(EntityResolver entityResolver) {
			this.entityResolver = entityResolver;
		}

		public EntityResolver getEntityResolver() {
			return this.entityResolver;
		}

		public void setDTDHandler(DTDHandler dtdHandler) {
			this.dtdHandler = dtdHandler;
		}

		public DTDHandler getDTDHandler() {
			return this.dtdHandler;
		}

		public void setContentHandler(ContentHandler contentHandler) {
			this.contentHandler = contentHandler;
		}

		public ContentHandler getContentHandler() {
			return this.contentHandler;
		}

		public void setErrorHandler(ErrorHandler errorHandler) {
			this.errorHandler = errorHandler;
		}

		public ErrorHandler getErrorHandler() {
			return this.errorHandler;
		}
	}
}
