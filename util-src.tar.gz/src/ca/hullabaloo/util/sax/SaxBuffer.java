/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * --------------------------------------------------------
 * Since this is based on APACHE code I'm required to have the above copyright 
 * notice, and to clearly state that this file has been changed my me (it's 
 * a Derivative Work).  This is that notice:
 * 
 * Re-implemented to better support LexicalHandler - Darren Gilroy
 */
package ca.hullabaloo.util.sax;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;

/**
 * A class that can record SAX events and replay them later.
 * 
 * <p>
 * Use this class if you need to frequently generate smaller amounts of SAX
 * events, or replay a set of recorded start events immediately.
 * </p>
 * 
 * <p>
 * Both ContentHandler and LexicalHandler are supported, the only exception is
 * that the setDocumentLocator event is not recorded.
 * </p>
 * 
 * <p>
 * The original package for this class is <code>org.apache.cocoon.xml</code>
 * </p>
 * 
 * <p>
 * Note this class is not strictly thread-safe, although once the buffer is
 * built, you can safely call toSAX() from multiple threads (as long as there
 * are no concurrent modifications).
 * </p>
 * 
 * @author <a href="mailto:dev@cocoon.apache.org">Apache Cocoon Team</a>
 * @author Darren Gilroy
 */
public class SaxBuffer implements ContentHandler, LexicalHandler {
	/** Stores list of {@link SaxBit} objects. */
	protected List<SaxBit> saxbits = new ArrayList<SaxBit>(100);

	/**
	 * Creates empty SaxBuffer
	 */
	public SaxBuffer() {
	}

	/**
	 * Creates copy of another SaxBuffer
	 * 
	 * @param saxBuffer
	 */
	public SaxBuffer(SaxBuffer saxBuffer) {
		append(saxBuffer);
	}

	/**
	 * @see ContentHandler#setDocumentLocator(org.xml.sax.Locator)
	 */
	public void setDocumentLocator(Locator locator) {
		// don't record this event
	}

	/**
	 * Returns true if this SaxBuffer is emmpty.
	 * 
	 * @return true if empty
	 */
	public boolean isEmpty() {
		return saxbits.isEmpty();
	}

	/**
	 * Appends the bits in the SaxBuffer to this Buffer. Much the same as
	 * otherBuffer.toSax(thisBuffer), except doesn't create new copies of the
	 * bits objects.
	 * 
	 * @param saxBuffer
	 *            the buffer to append
	 */
	public void append(SaxBuffer saxBuffer) {
		this.saxbits.addAll(saxBuffer.saxbits);
	}

	/**
	 * @see ContentHandler#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		saxbits.add(new Characters(ch, start, length));
	}

	/**
	 * @see LexicalHandler#comment(char[], int, int)
	 */
	public void comment(char[] ch, int start, int length) throws SAXException {
		saxbits.add(new Comment(ch, start, length));
	}

	/**
	 * @see LexicalHandler#endCDATA();
	 */
	public void endCDATA() throws SAXException {
		saxbits.add(EndCDATA.SINGLETON);
	}

	/**
	 * @see LexicalHandler#endDTD()
	 */
	public void endDTD() throws SAXException {
		saxbits.add(EndDTD.SINGLETON);
	}

	/**
	 * @see ContentHandler#endDocument()
	 */
	public void endDocument() throws SAXException {
		saxbits.add(EndDocument.SINGLETON);
	}

	/**
	 * @see ContentHandler#endElement(java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {
		saxbits.add(new EndElement(namespaceURI, localName, qName));
	}

	/**
	 * @see LexicalHandler#endEntity(java.lang.String)
	 */
	public void endEntity(String name) throws SAXException {
		saxbits.add(new EndEntity(name));
	}

	/**
	 * @see ContentHandler#endPrefixMapping(java.lang.String)
	 */
	public void endPrefixMapping(String prefix) throws SAXException {
		saxbits.add(new EndPrefixMapping(prefix));
	}

	/**
	 * @see ContentHandler#ignorableWhitespace(char[], int, int)
	 */
	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
		saxbits.add(new IgnorableWhitespace(ch, start, length));
	}

	/**
	 * @see ContentHandler#processingInstruction(java.lang.String,
	 *      java.lang.String)
	 */
	public void processingInstruction(String target, String data)
			throws SAXException {
		saxbits.add(new PI(target, data));
	}

	/**
	 * Clears the data stored in this buffer.
	 */
	public void recycle() {
		saxbits.clear();
	}

	/**
	 * @see ContentHandler#skippedEntity(java.lang.String)
	 */
	public void skippedEntity(String name) throws SAXException {
		saxbits.add(new SkippedEntity(name));
	}

	/**
	 * @see LexicalHandler#startCDATA()
	 */
	public void startCDATA() throws SAXException {
		saxbits.add(StartCDATA.SINGLETON);
	}

	/**
	 * @see LexicalHandler#startDTD(java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void startDTD(String name, String publicId, String systemId)
			throws SAXException {
		saxbits.add(new StartDTD(name, publicId, systemId));
	}

	/**
	 * @see ContentHandler#startDocument()
	 */
	public void startDocument() throws SAXException {
		saxbits.add(StartDocument.SINGLETON);
	}

	/**
	 * @see ContentHandler#startElement(java.lang.String, java.lang.String,
	 *      java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {
		saxbits.add(new StartElement(namespaceURI, localName, qName, atts));
	}

	/**
	 * @see LexicalHandler#startEntity(java.lang.String)
	 */
	public void startEntity(String name) throws SAXException {
		saxbits.add(new StartEntity(name));
	}

	/**
	 * @see ContentHandler#startPrefixMapping(java.lang.String,
	 *      java.lang.String)
	 */
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		saxbits.add(new StartPrefixMapping(prefix, uri));
	}

	/**
	 * Sends the events to the content handler
	 * 
	 * @param contentHandler
	 *            the destination
	 * 
	 * @throws SAXException
	 *             from the content handler
	 */
	public void toSAX(ContentHandler contentHandler) throws SAXException {
		if (contentHandler instanceof LexicalHandler)
			toSAX(contentHandler, (LexicalHandler) contentHandler);
		else
			toSAX(contentHandler, SAXUtils.DEFAULT_HANDLER);
	}

	/**
	 * Sends the events to the content handler
	 * 
	 * @param contentHandler
	 *            the destinations
	 * 
	 * @throws SAXException
	 *             from the content handler
	 */
	public void toSAX(ContentHandler contentHandler,
			LexicalHandler lexicalHandler) throws SAXException {
		for (Iterator i = saxbits.iterator(); i.hasNext();) {
			SaxBit saxbit = (SaxBit) i.next();
			saxbit.send(contentHandler, lexicalHandler);
		}
	}

	/**
	 * Used in i18n XML bundle implementation
	 * 
	 * @return string
	 */
	public String toString() {
		StringBuffer value = new StringBuffer();

		for (Iterator i = saxbits.iterator(); i.hasNext();) {
			SaxBit saxbit = (SaxBit) i.next();

			if (saxbit instanceof Characters) {
				((Characters) saxbit).toString(value);
			}
		}

		return value.toString();
	}

	/**
	 * Adds a SaxBit to the bits list
	 * 
	 * @param bit -
	 */
	protected final void addBit(SaxBit bit) {
		saxbits.add(bit);
	}

	/**
	 * Iterates through the bits list
	 * 
	 * @return Iterator
	 */
	protected final Iterator bits() {
		return saxbits.iterator();
	}

	/**
	 * SaxBit is a representation of the SAX event. Every SaxBit is immutable
	 * object.
	 */
	interface SaxBit {
		/**
		 * Replay the event to the ContentHandler or lexical handler
		 * 
		 * @param contentHandler
		 *            target
		 * 
		 * @throws SAXException
		 *             api
		 */
		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException;

	}

	/**
	 * Represents a SAX Event
	 */
	static final class Characters implements SaxBit {
		private final char[] ch;

		/**
		 * Creates a new Characters object.
		 * 
		 * @param ch
		 * @param start
		 * @param length
		 */
		public Characters(char[] ch, int start, int length) {
			// make a copy so that we don't hold references to a potentially
			// large array we don't control
			this.ch = new char[length];
			System.arraycopy(ch, start, this.ch, 0, length);
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.characters(ch, 0, ch.length);
		}

		/**
		 * Appends the characters to the passed stringbuffer
		 * 
		 * @param value
		 *            the buffer to append to.
		 */
		public void toString(StringBuffer value) {
			value.append(ch);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class Comment implements SaxBit {
		private final char[] ch;

		/**
		 * Creates a new Comment object.
		 * 
		 * @param ch
		 * @param start
		 * @param length
		 */
		public Comment(char[] ch, int start, int length) {
			// make a copy so that we don't hold references to a potentially
			// large array we don't control
			this.ch = new char[length];
			System.arraycopy(ch, start, this.ch, 0, length);
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.comment(ch, 0, ch.length);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class EndCDATA implements SaxBit {
		public static final EndCDATA SINGLETON = new EndCDATA();

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.endCDATA();
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class EndDTD implements SaxBit {
		public static final EndDTD SINGLETON = new EndDTD();

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.endDTD();
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class EndDocument implements SaxBit {
		public static final EndDocument SINGLETON = new EndDocument();

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.endDocument();
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class EndElement implements SaxBit {
		private final String localName;

		private final String namespaceURI;

		private final String qName;

		/**
		 * Creates a new EndElement object.
		 * 
		 * @param namespaceURI
		 * @param localName
		 * @param qName
		 */
		public EndElement(String namespaceURI, String localName, String qName) {
			this.namespaceURI = namespaceURI;
			this.localName = localName;
			this.qName = qName;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.endElement(namespaceURI, localName, qName);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class EndEntity implements SaxBit {
		private final String name;

		/**
		 * Creates a new EndEntity object.
		 * 
		 * @param name
		 */
		public EndEntity(String name) {
			this.name = name;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.endEntity(name);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class EndPrefixMapping implements SaxBit {
		private final String prefix;

		/**
		 * Creates a new EndPrefixMapping object.
		 * 
		 * @param prefix
		 */
		public EndPrefixMapping(String prefix) {
			this.prefix = prefix;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.endPrefixMapping(prefix);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class IgnorableWhitespace implements SaxBit {
		private final char[] ch;

		/**
		 * Creates a new IgnorableWhitespace object.
		 * 
		 * @param ch
		 * @param start
		 * @param length
		 */
		public IgnorableWhitespace(char[] ch, int start, int length) {
			// make a copy so that we don't hold references to a potentially
			// large array we don't control
			this.ch = new char[length];
			System.arraycopy(ch, start, this.ch, 0, length);
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.ignorableWhitespace(ch, 0, ch.length);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class PI implements SaxBit {
		private final String data;

		private final String target;

		/**
		 * Creates a new PI object.
		 * 
		 * @param target
		 * @param data
		 */
		public PI(String target, String data) {
			this.target = target;
			this.data = data;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.processingInstruction(target, data);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class SkippedEntity implements SaxBit {
		private final String name;

		/**
		 * Creates a new SkippedEntity object.
		 * 
		 * @param name
		 */
		public SkippedEntity(String name) {
			this.name = name;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.skippedEntity(name);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class StartCDATA implements SaxBit {
		public static final StartCDATA SINGLETON = new StartCDATA();

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.startCDATA();
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class StartDTD implements SaxBit {
		private final String name;

		private final String publicId;

		private final String systemId;

		/**
		 * Creates a new StartDTD object.
		 * 
		 * @param name
		 * @param publicId
		 * @param systemId
		 */
		public StartDTD(String name, String publicId, String systemId) {
			this.name = name;
			this.publicId = publicId;
			this.systemId = systemId;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.startDTD(name, publicId, systemId);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class StartDocument implements SaxBit {
		public static final StartDocument SINGLETON = new StartDocument();

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.startDocument();
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class StartElement implements SaxBit {
		private final Attributes attrs;

		private final String localName;

		private final String namespaceURI;

		private final String qName;

		/**
		 * Creates a new StartElement object.
		 * 
		 * @param namespaceURI
		 * @param localName
		 * @param qName
		 * @param attrs
		 */
		public StartElement(String namespaceURI, String localName,
				String qName, Attributes attrs) {
			this.namespaceURI = namespaceURI;
			this.localName = localName;
			this.qName = qName;
			this.attrs = new org.xml.sax.helpers.AttributesImpl(attrs);
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.startElement(namespaceURI, localName, qName, attrs);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class StartEntity implements SaxBit {
		private final String name;

		/**
		 * Creates a new StartEntity object.
		 * 
		 * @param name
		 */
		public StartEntity(String name) {
			this.name = name;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			lexicalHandler.startEntity(name);
		}
	}

	/**
	 * Represents a SAX Event
	 */
	static final class StartPrefixMapping implements SaxBit {
		private final String prefix;

		private final String uri;

		/**
		 * Creates a new StartPrefixMapping object.
		 * 
		 * @param prefix
		 * @param uri
		 */
		public StartPrefixMapping(String prefix, String uri) {
			this.prefix = prefix;
			this.uri = uri;
		}

		public void send(ContentHandler contentHandler,
				LexicalHandler lexicalHandler) throws SAXException {
			contentHandler.startPrefixMapping(prefix, uri);
		}
	}
}
