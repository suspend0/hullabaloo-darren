package ca.hullabaloo.util.sax;

import java.nio.CharBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * Replaces strings in SAX character events. Uses a single regex {@link Pattern}
 * to do the search, so if you're looking for a massive string-replacement
 * library you're probably better off looking elsewhere. This is great for a few
 * (less than 20) small strings.
 * 
 * <p>
 * <b>NOTE:</b> This only works across a single
 * {@link ContentHandler#characters(char[], int, int)} call, so it should be
 * prefaced with a {@link
 * com.fujitsu.fbf.fbf2.util.sax.SaxCharacterConsolidationFilter}.
 * </p>
 * 
 * @author Darren Gilroy
 */
public class SaxStringReplaceFilter extends XMLFilterImpl {
	/** chooses elements to work on */
	private final ElementSelector m_selector;

	/** replacement -- key is the search, value is the replacement */
	private Map<String, char[]> m_strings = new HashMap<String, char[]>();

	/** pattern used to match */
	private Pattern m_pattern;

	/**
	 * Creates a new SaxStringReplaceFilter
	 * 
	 * @param parent
	 *            the parent XMLReader
	 * @param selector
	 *            only processes text when {@link ElementSelector#isSelected()}
	 *            is true.
	 */
	public SaxStringReplaceFilter(XMLReader parent, ElementSelector selector) {
		super(parent);
		m_selector = selector;
	}

	/**
	 * Creates a new SaxStringReplaceFilter
	 * 
	 * @param selector
	 *            only processes text when {@link ElementSelector#isSelected()}
	 *            is true.
	 */
	public SaxStringReplaceFilter(ElementSelector selector) {
		super();
		m_selector = selector;
	}

	/**
	 * Registers a string for replacement.
	 * 
	 * @param search
	 *            the string to search for
	 * @param replace
	 *            the string to replace it with
	 * 
	 * @throws NullPointerException
	 *             if either the search or replace string is null
	 * @throws IllegalArgumentException
	 *             if the search string is the empty string
	 */
	public void addSearchPattern(String search, String replace) {
		if ((search == null) || (replace == null)) {
			throw new NullPointerException(
					"Search and replace patterns must be non-null.");
		}

		if (search.length() == 0) {
			throw new IllegalArgumentException(
					"Cannot search for empty string.");
		}

		m_strings.put(search, replace.toCharArray());
		compilePattern();
	}

	/**
	 * Does the work of conversion.
	 * 
	 * @param ch
	 *            {@inheritDoc}
	 * @param start
	 *            {@inheritDoc}
	 * @param length
	 *            {@inheritDoc}
	 * 
	 * @throws SAXException
	 *             per api
	 */
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (m_selector.isSelected()) {
			Matcher m = m_pattern.matcher(CharBuffer.wrap(ch, start, length));

			int pos = 0;

			while (m.find()) {
				// this is from the last position to this match
				super.characters(ch, start + pos, m.start() - pos);

				// then we get and send the un-escaped value
				char[] ent = (char[]) m_strings.get(m.group(1));
				super.characters(ent, 0, ent.length);

				//
				pos = m.end();
			}

			// appendTail
			super.characters(ch, start + pos, length - pos);

			//
		} else {
			// pass-through
			super.characters(ch, start, length);
		}
	}

	/**
	 * Removes all registered search patterns. You must add at least one pattern
	 * before parsing.
	 */
	public void clearSearchPatterns() {
		m_strings.clear();
		m_pattern = null;
	}

	/**
	 * Removes a search pattern.
	 * 
	 * @param search
	 *            The search string
	 * 
	 * @return the previous replacement value, or null if the string did not
	 *         exist.
	 */
	public String removeSearchPattern(String search) {
		char[] r = m_strings.remove(search);
		compilePattern();

		return new String(r);
	}

	/**
	 * Verify we have registred some entities to look for.
	 * 
	 * @throws SAXException
	 *             if there are no registered patterns.
	 */
	public void startDocument() throws SAXException {
		if (m_pattern == null) {
			throw new SAXException(
					"Must call addReplacement() at least once before parsing.");
		}

		super.startDocument();
	}

	/**
	 * Compiles the search-replace map into a regular expression.
	 */
	private void compilePattern() {
		m_pattern = null;

		// compile pattern
		StringBuffer pat = new StringBuffer();

		char c = '(';

		for (Iterator i = m_strings.keySet().iterator(); i.hasNext();) {
			pat.append(c);
			pat.append("\\Q");

			// escape all backslashes
			pat.append(((String) i.next()).replaceAll("\\\\", "\\\\\\\\"));
			pat.append("\\E");
			c = '|';
		}

		pat.append(')');

		// compile!
		m_pattern = Pattern.compile(pat.toString());
	}
}
