package ca.hullabaloo.util.sax;

/**
 * Tells when an element is selected.
 * 
 * @author Darren Gilroy
 */
public interface ElementSelector {
	/**
	 * If we are currently in a selected tag.
	 * 
	 * @return true if we are in a "selected" element, false otherwise.
	 */
	public boolean isSelected();
}
