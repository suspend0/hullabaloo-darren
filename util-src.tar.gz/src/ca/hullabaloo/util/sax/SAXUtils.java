package ca.hullabaloo.util.sax;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.AttributesImpl;

/**
 * Collection of utility methods to facilitate SAX event handling.
 * 
 * @author Darren Gilroy
 */
public class SAXUtils {

	/**
	 * Empty AttributesImpl instance.
	 */
	public static final Attributes EMPTY_ATTR = new AttributesImpl();

	/**
	 * Content Handler instance
	 */
	public static final DefaultHandler2 DEFAULT_HANDLER = new DefaultHandler2();

	/** Instances should not be constructed, use static methods */
	public SAXUtils() {
		// no-op
	}

	/**
	 * Convert SAX Attributes to a Map
	 * 
	 * @param atts
	 *            The attributes to convert
	 * 
	 * @return A map
	 */
	public static Map attributesToMap(Attributes atts) {
		int len = atts.getLength();
		Map<String, String> m = new HashMap<String, String>(len, 1.1F);

		for (int i = 0; i < len; i++) {
			m.put(atts.getQName(i), atts.getValue(i));
		}

		return m;
	}

	/**
	 * Creates a new document builder
	 * 
	 * @throws ParserConfigurationException
	 */
	public static DocumentBuilder newDocumentBuilder() {
		try {
			return DocumentBuilderFactory.newInstance().newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		}
	}

	/** Parses a document, using a buffered InputStream */
	public static Document newDocument(InputStream in, int bufSize)
			throws IOException, SAXException {
		return newDocument(new BufferedInputStream(in, bufSize));
	}

	/** Parses a document */
	public static Document newDocument(InputStream in) throws IOException,
			SAXException {
		Document doc = newDocumentBuilder().parse(in);
		return doc;
	}

	/** Parses a document, using a buffered reader */
	public static Document newDocument(Reader in, int bufSize)
			throws IOException, SAXException {
		return newDocument(new BufferedReader(in, bufSize));
	}

	/** Parses a document */
	public static Document newDocument(Reader in) throws IOException,
			SAXException {
		return newDocument(new InputSource(in));
	}

	/** Parses a document */
	public static Document newDocument(InputSource in) throws IOException,
			SAXException {
		Document doc = newDocumentBuilder().parse(in);
		return doc;
	}

	/**
	 * Creates a new instance of {@see org.xml.sax.Attributes} from the given
	 * parameter strings. The attributes need to be given in pairs, e.g. "id",
	 * "1234" - This will create "id=1234".
	 * 
	 * @param args
	 *            attribute name-value pairs
	 * @return a new instance of Attributes
	 */
	public static Attributes newAttributes(String... args) {
		// zero-length arg is OK
		if (args.length == 0)
			return SAXUtils.EMPTY_ATTR;

		// otherwise must come in pairs
		if (args.length % 2 != 0)
			throw new IllegalArgumentException("arguments must come in pairs");

		AttributesImpl attributes = new AttributesImpl();
		for (int i = 0; i < args.length; ++i) {
			String name = args[i];
			String value = args[++i];
			if (value != null && value.length() > 0)
				attributes.addAttribute("", name, name, "", value);
		}
		return attributes;
	}

}
