package ca.hullabaloo.util.sax;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * Splits a document to different content handlers. Each time a new element is
 * selected by the {@link com.fujitsu.fbf.fbf2.util.sax.SaxElementSelector} the
 * element is sent to a new content handler.
 * 
 * @author Darren Gilroy
 */
public class DocumentSplitterFilter extends XMLFilterImpl {
	/** The elements that get sent to the child content handlers */
	private final SaxElementSelector selector;

	/** Our current handler for split docs */
	private ContentHandler handler;

	/** Where we can get the contenthandlers to receive our docs */
	private ContentHandlerFactory contentHandlerFactory;

	/**
	 * @see XMLFilterImpl#XMLFilterImpl(org.xml.sax.XMLReader)
	 */
	public DocumentSplitterFilter(SaxElementSelector selector) {
		this.selector = selector;
	}

	/**
	 * Sets the content handler factory
	 * 
	 * @param factory
	 *            the content handler factory to use.
	 */
	public void setContentHandlerFactory(ContentHandlerFactory factory) {
		this.contentHandlerFactory = factory;
	}

	/**
	 * @see ContentHandler#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (this.handler != null) {
			this.handler.characters(ch, start, length);
		} else {
			super.characters(ch, start, length);
		}
	}

	/**
	 * @see ContentHandler#endElement(java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (this.handler == null) {
			super.endElement(uri, localName, qName);
		} else {
			this.handler.endElement(uri, localName, qName);

			if (this.selector.isEndElement()) {
				this.handler.endDocument();
				this.handler = null;
			}
		}
	}

	/**
	 * @see ContentHandler#endPrefixMapping(java.lang.String)
	 */
	public void endPrefixMapping(String prefix) throws SAXException {
		if (this.handler == null) {
			super.endPrefixMapping(prefix);
		} else {
			this.handler.endPrefixMapping(prefix);
		}
	}

	/**
	 * @see ContentHandler#ignorableWhitespace(char[], int, int)
	 */
	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
		if (this.handler == null) {
			super.ignorableWhitespace(ch, start, length);
		} else {
			this.handler.ignorableWhitespace(ch, start, length);
		}
	}

	/**
	 * @see ContentHandler#processingInstruction(java.lang.String,
	 *      java.lang.String)
	 */
	public void processingInstruction(String target, String data)
			throws SAXException {
		if (this.handler == null) {
			super.processingInstruction(target, data);
		} else {
			this.handler.processingInstruction(target, data);
		}
	}

	/**
	 * @see ContentHandler#skippedEntity(java.lang.String)
	 */
	public void skippedEntity(String name) throws SAXException {
		if (this.handler == null) {
			super.skippedEntity(name);
		} else {
			this.handler.skippedEntity(name);
		}
	}

	/**
	 * check to see that a content handler factory has been set
	 * 
	 * @throws SAXException
	 *             per api
	 */
	public void startDocument() throws SAXException {
		if (this.contentHandlerFactory == null) {
			throw new SAXException(
					"The content handler factory must be set before parsing");
		}

		super.startDocument();
	}

	/**
	 * @see ContentHandler#startElement(java.lang.String, java.lang.String,
	 *      java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		if (this.handler == null) {
			if (this.selector.isStartElement()) {
				this.handler = this.contentHandlerFactory.getContentHandler();
				this.handler.startDocument();
				this.handler.startElement(uri, localName, qName, atts);
			} else {
				super.startElement(uri, localName, qName, atts);
			}
		} else {
			this.handler.startElement(uri, localName, qName, atts);
		}
	}

	/**
	 * @see ContentHandler#startPrefixMapping(java.lang.String,
	 *      java.lang.String)
	 */
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		if (this.handler == null) {
			super.startPrefixMapping(prefix, uri);
		} else {
			this.handler.startPrefixMapping(prefix, uri);
		}
	}
}
