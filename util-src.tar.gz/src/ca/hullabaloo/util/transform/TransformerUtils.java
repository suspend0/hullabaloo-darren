package ca.hullabaloo.util.transform;

import java.io.StringWriter;
import java.io.Writer;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Node;

public class TransformerUtils {

	/** TransformerFactory */
	private static final ThreadLocal<SAXTransformerFactory> tfact = new ThreadLocal<SAXTransformerFactory>() {
		@Override
		public SAXTransformerFactory initialValue() {
			return (SAXTransformerFactory) SAXTransformerFactory.newInstance();
		}
	};

	public static TransformerHandler identityTransformerHandler()
			throws TransformerConfigurationException {
		TransformerHandler tfh = tfact.get().newTransformerHandler();
		return tfh;
	}

	public static TransformerHandler identityTransformerHandler(Result result)
			throws TransformerConfigurationException {
		TransformerHandler tfh = identityTransformerHandler();
		tfh.setResult(result);
		return tfh;
	}

	public static TransformerHandler identityTransformerHandler(Result result,
			String... outputProps) throws TransformerConfigurationException {
		if (false == (outputProps.length == 0 || outputProps.length % 2 == 0))
			throw new IllegalArgumentException(
					"Must pass even number of output properties");

		TransformerHandler tfh = identityTransformerHandler(result);

		Transformer xform = tfh.getTransformer();
		for (int i = 0; i < outputProps.length; i += 2)
			xform.setOutputProperty(outputProps[i], outputProps[i + 1]);

		return tfh;
	}

	public static void identityTransform(Source source, Result result)
			throws TransformerException {
		Transformer xform = tfact.get().newTransformer();
		xform.transform(source, result);
	}

	public static void identityTransform(Node doc, Writer writer)
			throws TransformerException {
		identityTransform(new DOMSource(doc), new StreamResult(writer));
	}

	public static Templates newTemplates(Source source)
			throws TransformerConfigurationException {
		return tfact.get().newTemplates(source);
	}

	public static String toString(Source source) throws TransformerException {
		StringWriter wtr = new StringWriter();
		identityTransform(source, new StreamResult(wtr));
		return wtr.toString();
	}

}
