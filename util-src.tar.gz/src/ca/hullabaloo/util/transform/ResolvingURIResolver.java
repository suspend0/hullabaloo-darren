package ca.hullabaloo.util.transform;

import java.net.URI;
import java.net.URISyntaxException;

import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;

/**
 * Simply resolves the href against the base before passing to the delegate.
 * Useful in {@link URIREsolverChain}s where it's wasteful to resolve the url
 * each time.
 * 
 * @author darren
 */
public class ResolvingURIResolver implements URIResolver {
	private final URIResolver delegate;

	/** Creates a new ResolvingURIResolver, passing requests to the delegate */
	public ResolvingURIResolver(URIResolver delegate) {
		if (delegate == null)
			throw new NullPointerException(
					"Can not delegate to a null resolver");

		this.delegate = delegate;
	}

	/**
	 * Resolves the href against he base, and then passes
	 * <code>(resolved,null)</code> to the delegate.
	 */
	public Source resolve(String href, String base) throws TransformerException {
		if (base == null) {
			return delegate.resolve(href, null);
		}

		if (href.startsWith("fbf://") || href.startsWith("http://")
				|| href.startsWith("https://")) {
			return delegate.resolve(href, null);
		}

		try {
			URI uri = new URI(base).resolve(href);
			return delegate.resolve(uri.toString(), null);

			//
		} catch (URISyntaxException e) {
			throw new TransformerException("Error resolving " + href
					+ " against " + base, e);
		}

	}

	/** Returns the delegate */
	public URIResolver getWrapped() {
		return this.delegate;
	}

}
