package ca.hullabaloo.util.transform;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;

/**
 * A URI resolver that resolves a url from each resolver in series until a
 * non-null result is returned.
 * <p>
 * This class is <b>not synchronized</b>, do not add resolvers when you are
 * resolving with this class.
 * </p>
 * 
 * @author Darren Gilroy
 * @version $Revision$
 */
public class URIResolverChain implements URIResolver {
	// Logger
	private static final Logger logger = Logger
			.getLogger(URIResolverChain.class.getName());

	/** No-op resolver */
	private static final URIResolver NO_OP_RESOLVER = new URIResolver() {
		public Source resolve(String href, String base)
				throws TransformerException {
			return null;
		}
	};

	/** The resolver chain */
	private final List<URIResolver> resolverChain = new ArrayList<URIResolver>();

	/** The resolver we resolve with */
	private URIResolver resolver;

	/** Resolve the base before entering the chain */
	private boolean resolveBase = true;

	/** If we're using the full implementation */
	private boolean usingFullImpl = false;

	/**
	 * Creates a new URIResolverChain object.
	 */
	public URIResolverChain() {
		// default resolver in case somebody tries to use it with no underlying
		// resolvers
		this.resolver = NO_OP_RESOLVER;
	}

	/**
	 * Creates a new URIResolverChain object.
	 * 
	 * @param resolver1
	 */
	public URIResolverChain(URIResolver resolver1) {
		if (resolver1 == null)
			throw new NullPointerException("Resolver1 is null");

		this.resolverChain.add(resolver1);
		makeResolver();
	}

	/**
	 * Creates a new URIResolverChain object.
	 * 
	 * @param resolver1
	 * @param resolver2
	 */
	public URIResolverChain(URIResolver resolver1, URIResolver resolver2) {
		if (resolver1 == null)
			throw new NullPointerException("Resolver1 is null");
		if (resolver2 == null)
			throw new NullPointerException("Resolver2 is null");

		this.resolverChain.add(resolver1);
		this.resolverChain.add(resolver2);
		makeResolver();
	}

	/**
	 * Creates a new URIResolverChain object.
	 * 
	 * @param resolver1
	 * @param resolver2
	 * @param resolver3
	 */
	public URIResolverChain(URIResolver resolver1, URIResolver resolver2,
			URIResolver resolver3) {
		if (resolver1 == null)
			throw new NullPointerException("Resolver1 is null");
		if (resolver2 == null)
			throw new NullPointerException("Resolver2 is null");
		if (resolver3 == null)
			throw new NullPointerException("Resolver3 is null");

		this.resolverChain.add(resolver1);
		this.resolverChain.add(resolver2);
		this.resolverChain.add(resolver3);
		makeResolver();
	}

	/**
	 * Adds a resolver to the chain.
	 * 
	 * @param resolver
	 *            the resolver to add
	 */
	public void addResolver(final URIResolver resolver) {
		if (resolver == null)
			throw new NullPointerException("Resolver is null");

		this.resolverChain.add(resolver);
		makeResolver();
	}

	/** Clears the resolver chain */
	public void clear() {
		this.resolverChain.clear();
		makeResolver();
	}

	/** If we should use the resolver */
	public void doResolveBase(boolean resolve) {
		this.resolveBase = resolve;
	}

	/**
	 * Resolves using the chain
	 * 
	 * @param href
	 *            the href
	 * @param base
	 *            the base
	 * @return a Source, or null
	 * @throws TransformerException
	 *             problem
	 */
	public Source resolve(String href, String base) throws TransformerException {
		return this.resolver.resolve(href, base);
	}

	/** Makes the resolver from the current chain */
	private void makeResolver() {
		if (this.usingFullImpl)
			return;

		switch (this.resolverChain.size()) {
		case 0:
			this.resolver = NO_OP_RESOLVER;
			break;
		case 1:
			this.resolver = this.resolverChain.get(0);
			break;
		case 2:
			this.resolver = newChain(this.resolverChain.get(0),
					this.resolverChain.get(1));
			break;
		case 3:
			this.resolver = newChain(this.resolverChain.get(0),
					this.resolverChain.get(1), this.resolverChain.get(2));
			break;
		default:
			this.usingFullImpl = true;
			this.resolver = new URIResolverChainImpl(this.resolverChain);
		}

		if (this.resolveBase)
			this.resolver = new ResolvingURIResolver(this.resolver);
	}

	/**
	 * Returns a URIResolver (not necessarily an instance of URIResolverChain)
	 * optimized for two resolvers)
	 * 
	 * @param resolver1
	 *            the first resolver
	 * @param resolver2
	 *            the second resolver
	 * @return a resolver
	 */
	private static URIResolver newChain(final URIResolver resolver1,
			final URIResolver resolver2) {
		return new URIResolver() {
			public Source resolve(String href, String base)
					throws TransformerException {
				logger.finer(href);

				Source r = null;

				if ((r = resolver1.resolve(href, base)) != null) {
					return r;
				}

				if ((r = resolver2.resolve(href, base)) != null) {
					return r;
				}

				logger.finer("Returning null");

				return null;
			}
		};
	}

	/**
	 * Returns a URIResolver (not necessarily an instance of URIResolverChain)
	 * optimized for three resolvers)
	 * 
	 * @param resolver1
	 *            the first resolver
	 * @param resolver2
	 *            the second resolver
	 * @param resolver3
	 *            the third resolver
	 * @return a URIResolver
	 */
	private static URIResolver newChain(final URIResolver resolver1,
			final URIResolver resolver2, final URIResolver resolver3) {
		return new URIResolver() {
			public Source resolve(String href, String base)
					throws TransformerException {
				logger.finer(href);

				Source r = null;

				if ((r = resolver1.resolve(href, base)) != null) {
					return r;
				}

				if ((r = resolver2.resolve(href, base)) != null) {
					return r;
				}

				if ((r = resolver3.resolve(href, base)) != null) {
					return r;
				}

				logger.finer("Returning null");

				return null;
			}
		};
	}

	/**
	 * Class that uses a dynamic list of resolvers.
	 */
	private static class URIResolverChainImpl implements URIResolver {
		private final List<URIResolver> chain;

		/**
		 * Creates a new URIResolverChainImpl object.
		 * 
		 * @param chain
		 *            the list of resolvers to use.
		 */
		URIResolverChainImpl(List<URIResolver> chain) {
			this.chain = chain;
		}

		/**
		 * Resolve the url
		 * 
		 * @param href
		 *            the href
		 * @param base
		 *            the base
		 * @return a source, or null
		 * @throws TransformerException
		 *             problem
		 */
		public Source resolve(String href, String base)
				throws TransformerException {
			final int j = this.chain.size();

			for (int i = 0; i < j; i++) {
				Source r = this.chain.get(i).resolve(href, base);

				if (r != null) {
					return r;
				}
			}

			return null;
		}
	}
}
