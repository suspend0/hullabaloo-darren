package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.Reader;

/**
 * Counts the number of characters returned from this reader -- does not account
 * for {@link Reader#skip(long)}
 */
public class CountingReader extends ProxyReader {
	private long count = 0;

	public CountingReader(Reader reader) {
		super(reader);
	}

	public long getCount() {
		return count;
	}

	@Override
	public int read() throws IOException {
		int r = super.read();
		if (r != -1)
			count++;
		return r;
	}

	@Override
	public int read(char[] ch, int start, int len) throws IOException {
		int r = super.read(ch, start, len);
		count += Math.max(0, r);
		return r;
	}

	@Override
	public int read(char[] ch) throws IOException {
		int r = super.read(ch);
		count += Math.max(0, r);
		return r;
	}

}
