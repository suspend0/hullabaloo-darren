package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.Writer;

/** 
 * Deprecated: Use IOUtils ProxyWriter
 */
public class ProxyWriter extends Writer {
	protected final Writer out;

	public ProxyWriter(Writer writer) {
		this.out = writer;
	}

	@Override
	public Writer append(char arg0) throws IOException {
		return this.out.append(arg0);
	}

	@Override
	public Writer append(CharSequence cs, int start, int end)
			throws IOException {
		return this.out.append(cs, start, end);
	}

	@Override
	public Writer append(CharSequence cs) throws IOException {
		return this.out.append(cs);
	}

	@Override
	public void close() throws IOException {
		this.out.close();
	}

	@Override
	public void flush() throws IOException {
		this.out.flush();
	}

	@Override
	public void write(char[] ch, int offset, int len) throws IOException {
		this.out.write(ch, offset, len);
	}

	@Override
	public void write(char[] ch) throws IOException {
		this.out.write(ch);
	}

	@Override
	public void write(int c) throws IOException {
		this.out.write(c);
	}

	@Override
	public void write(String str, int offset, int len) throws IOException {
		this.out.write(str, offset, len);
	}

	@Override
	public void write(String str) throws IOException {
		this.out.write(str);
	}
}
