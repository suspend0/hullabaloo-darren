package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.Writer;

import ca.hullabaloo.util.ArrayCharSequence;

/**
 * Wraps an appendable in a Writer
 * 
 * @author Darren Gilroy
 */
public class AppendableWriter extends Writer {
	private final Appendable buf;

	private final ArrayCharSequence seq = new ArrayCharSequence();

	public AppendableWriter(Appendable buf) {
		this.buf = buf;
	}

	@Override
	public Writer append(char c) throws IOException {
		this.buf.append(c);
		return this;
	}

	@Override
	public Writer append(CharSequence ch, int start, int length)
			throws IOException {
		this.buf.append(ch, start, length);
		return this;
	}

	@Override
	public Writer append(CharSequence seq) throws IOException {
		this.buf.append(seq);
		return this;
	}

	@Override
	public void write(String str, int start, int length) throws IOException {
		this.buf.append(str, start, length);
	}

	@Override
	public void write(String str) throws IOException {
		this.buf.append(str);
	}

	@Override
	public void write(char[] ch, int start, int length) throws IOException {
		this.seq.setCharArray(ch, start, length);
		this.buf.append(seq);
	}

	@Override
	public void close() throws IOException { // no-op
	}

	@Override
	public void flush() throws IOException { // no-op
	}

}
