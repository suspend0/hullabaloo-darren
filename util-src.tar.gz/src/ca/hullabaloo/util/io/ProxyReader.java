package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.Reader;
import java.nio.CharBuffer;

/**
 * Deprecated: Use IOUtils ProxyReader
 */
public class ProxyReader extends Reader {
	private final Reader delegate;

	/**
	 * Create a DelegatingReader with the given delegate
	 * 
	 * @param delegate
	 */
	public ProxyReader(final Reader delegate) {
		this.delegate = delegate;
	}

	/**
	 * @see java.io.Reader#close()
	 */
	@Override
	public void close() throws IOException {
		this.delegate.close();
	}

	/**
	 * @return Returns the delegate.
	 */
	public Reader getDelegate() {
		return this.delegate;
	}

	/**
	 * @see java.io.Reader#mark(int)
	 */
	@Override
	public void mark(int readAheadLimit) throws IOException {
		this.delegate.mark(readAheadLimit);
	}

	/**
	 * @see java.io.Reader#markSupported()
	 */
	@Override
	public boolean markSupported() {
		return this.delegate.markSupported();
	}

	/**
	 * @see java.io.Reader#read()
	 */
	@Override
	public int read() throws IOException {
		return this.delegate.read();
	}

	/**
	 * @see java.io.Reader#read(char[])
	 */
	@Override
	public int read(char[] cbuf) throws IOException {
		return this.delegate.read(cbuf);
	}

	/**
	 * @see java.io.Reader#read(char[], int, int)
	 */
	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		return this.delegate.read(cbuf, off, len);
	}

	/**
	 * @see java.io.Reader#read(java.nio.CharBuffer)
	 */
	@Override
	public int read(CharBuffer target) throws IOException {
		return this.delegate.read(target);
	}

	/**
	 * @see java.io.Reader#ready()
	 */
	@Override
	public boolean ready() throws IOException {
		return this.delegate.ready();
	}

	/**
	 * @see java.io.Reader#reset()
	 */
	@Override
	public void reset() throws IOException {
		this.delegate.reset();
	}

	/**
	 * @see java.io.Reader#skip(long)
	 */
	@Override
	public long skip(long n) throws IOException {
		return this.delegate.skip(n);
	}

}