package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;

/**
 * This class convert Reader to InputStream. It works by converting the
 * characters to the encoding specified in constructor parameter.
 * 
 * @author Darren Giroy
 */
public class ReaderInputStream extends InputStream {
	private final Reader reader;

	private final CharsetEncoder encoder;

	private final CharBuffer cbuf;

	private final ByteBuffer bbuf;

	private enum State {
		NORMAL, INPUT_EXHAUSTED, FLUSHING, COMPLETE
	}

	private State state = State.NORMAL;

	/**
	 * Creates new input stream from the given reader and encoding.
	 * 
	 * @param reader
	 *            Input reader
	 * @param encoding
	 * @throws IOException
	 */
	public ReaderInputStream(Reader reader, Charset encoding)
			throws IOException {
		this.reader = reader;
		this.encoder = encoding.newEncoder();
		this.cbuf = CharBuffer.allocate(2048);
		this.bbuf = ByteBuffer.allocate(((int) (2048f * encoder
				.averageBytesPerChar())) + 8);
	}

	@Override
	public int read() throws IOException {
		if (bbuf.hasRemaining() == false)
			fillBuffer();
		if (bbuf.hasRemaining() == false)
			return -1;
		return bbuf.getInt();
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		if (bbuf.hasRemaining() == false)
			fillBuffer();
		if (bbuf.hasRemaining() == false)
			return -1;

		int cnt = Math.min(len, bbuf.remaining());

		bbuf.get(b, off, cnt);

		return cnt;
	}

	private void fillBuffer() throws IOException {
		bbuf.compact();
		cbuf.compact();

		CoderResult res;

		switch (this.state) {
		case NORMAL:
			// We have more input, go ahead and get it
			int cnt = reader.read(cbuf);
			if (cnt == -1)
				this.state = State.INPUT_EXHAUSTED;

			// reads from cbuf, writes to bbuf
			res = encoder.encode(cbuf, bbuf, false);
			if (res.isError())
				res.throwException();

			break;
		case INPUT_EXHAUSTED:
			// do a regular encode ...
			res = encoder.encode(cbuf, bbuf, false);
			if (res.isError())
				res.throwException();

			// until we have exhaused our input
			if (res.isUnderflow()) {
				// signal no-more-characters
				res = encoder.encode(cbuf, bbuf, true);
				if (res.isError())
					res.throwException();
				this.state = State.FLUSHING;
			}
			break;
		case FLUSHING:
			res = encoder.flush(bbuf);
			if (res.isError())
				res.throwException();
			if (res.isUnderflow())
				this.state = State.COMPLETE;
			break;
		case COMPLETE:
			// VERY VERY important this is return and not break, b/c we call
			// this recursively
			return;
		}

		// final checks -- if we coudn't encode anything, try again
		if (bbuf.hasRemaining() == false) {
			if (cbuf.hasRemaining())
				throw new IllegalStateException(
						"characters remain in input buffer, but did not encode to output buffer");

			fillBuffer();
		}
	}
}
