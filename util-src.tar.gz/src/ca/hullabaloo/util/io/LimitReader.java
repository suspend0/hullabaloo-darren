package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.Reader;

/**
 * Limits the number of characters returned from this reader -- does not account
 * for {@link Reader#skip(long)}
 * 
 * @author Darren Gilroy
 */
public class LimitReader extends CountingReader {
	private final long limit;

	public LimitReader(Reader reader, long limit) {
		super(reader);
		this.limit = limit;

		if (this.limit < 0)
			throw new IllegalArgumentException("Limit must be positive");
	}

	@Override
	public int read() throws IOException {
		if (getCount() >= limit)
			return -1;
		else
			return super.read();
	}

	@Override
	public int read(char[] ch, int start, int len) throws IOException {
		if (getCount() >= limit)
			return -1;

		// calcualate what our count will be after this method is called,
		// and possibly reduce the amount of data we're asking for if
		// it would be more than our limit.
		long count = len + getCount();
		if (count > limit)
			len -= (count - limit);

		return super.read(ch, start, len);
	}

	@Override
	public int read(char[] ch) throws IOException {
		return this.read(ch, 0, ch.length);
	}
}
