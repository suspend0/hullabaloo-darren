package ca.hullabaloo.util.io;

import java.io.IOException;
import java.io.Writer;

/** 
 * Duplicates a writer to two writer.
 * 
 * @author Darren Gilroy
 */
public class TeeWriter extends Writer {
	protected final Writer wtr;

	protected final Writer branch;

	public TeeWriter(Writer wtr, Writer branch) {
		this.wtr = wtr;
		this.branch = branch;
	}

	@Override
	public Writer append(char c) throws IOException {
		this.wtr.append(c);
		this.branch.append(c);
		return this;
	}

	@Override
	public Writer append(CharSequence csq, int start, int end)
			throws IOException {
		this.wtr.append(csq, start, end);
		this.branch.append(csq, start, end);
		return this;
	}

	@Override
	public Writer append(CharSequence csq) throws IOException {
		this.wtr.append(csq);
		this.branch.append(csq);
		return this;
	}

	@Override
	public void close() throws IOException {
		this.wtr.close();
		this.branch.close();
	}

	@Override
	public void flush() throws IOException {
		this.wtr.flush();
		this.branch.flush();
	}

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		this.wtr.write(cbuf, off, len);
		this.branch.write(cbuf, off, len);
	}

	@Override
	public void write(char[] cbuf) throws IOException {
		this.wtr.write(cbuf);
		this.branch.write(cbuf);
	}

	@Override
	public void write(int c) throws IOException {
		this.wtr.write(c);
		this.branch.write(c);
	}

	@Override
	public void write(String cbuf, int off, int len) throws IOException {
		this.wtr.write(cbuf, off, len);
		this.branch.write(cbuf, off, len);
	}

	@Override
	public void write(String arg0) throws IOException {
		this.wtr.write(arg0);
		this.branch.write(arg0);
	}

}
