package ca.hullabaloo.util.xml;

import java.io.IOException;
import java.io.Reader;
import java.util.Stack;

import org.apache.commons.lang.StringEscapeUtils;

import ca.hullabaloo.util.ArrayCharSequence;

/**
 * Class that helps build XML programatically
 * 
 * @author Darren Gilroy
 */
public class XMLBuilder {
	private enum State {
		NORMAL, ATTRIBUTES
	}

	/** The XML we are building */
	private final Appendable buf;

	/** The stack of open elements */
	private final Stack<String> elements = new Stack<String>();

	/** The current state */
	private State state = State.NORMAL;

	/** Creates a new XMLBuilder with no XML declaration */
	public XMLBuilder(Appendable buf) {
		this.buf = buf;
	}

	/**
	 * appends the declaration to the document
	 * 
	 * @throws IOException
	 */
	public XMLBuilder declaration(String version) throws IOException {
		final String decl = String.format("<?xml version=\"%s\"?>", version);
		this.buf.append(decl).append(System.getProperty("line.separator"));
		return this;
	}

	/**
	 * Appends the declaration to the document
	 * 
	 * @throws IOException
	 */
	public XMLBuilder declaration(String version, String encoding)
			throws IOException {
		final String decl = String.format(
				"<?xml version=\"%s\" encoding=\"%s\"?>", version, encoding);
		this.buf.append(decl).append(System.getProperty("line.separator"));
		return this;
	}

	/** Begin an element */
	public XMLBuilder openElement(String element) throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		this.elements.push(element);
		this.buf.append('<').append(element);
		this.state = State.ATTRIBUTES;
		return this;
	}

	/** End all open elements up to and including the named element */
	public XMLBuilder closeElement(String element) throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		String name;
		do {
			name = this.elements.pop();
			this.buf.append("</").append(name).append('>');
		} while (name.equals(element) == false);
		return this;
	}

	/** End the currently open element */
	public XMLBuilder closeElement() throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		final String element = this.elements.pop();
		this.buf.append("</").append(element).append('>');
		return this;
	}

	/**
	 * Add an attribute to the last open element. Must call before characters.
	 * If you pass null as a value, the attribute is NOT created. Pass the empty
	 * string if you want an attribute with no value.
	 */
	public XMLBuilder attribute(String name, String value) throws IOException {
		if (this.state != State.ATTRIBUTES)
			throw new IllegalStateException();

		if (value != null)
			this.buf.append(' ').append(name).append('=').append('"').append(
					StringEscapeUtils.escapeXml(value)).append('"');

		return this;
	}

	/** Add characters to an open element */
	public XMLBuilder characters(String chars) throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		this.buf.append(StringEscapeUtils.escapeXml(chars));
		return this;
	}

	/** Append raw content to the current buffer */
	public XMLBuilder appendRaw(CharSequence dat) throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		this.buf.append(dat);
		return this;
	}

	/** Appends raw content to the current buffer */
	public void appendRaw(Reader rdr) throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		int cnt = -1;

		// the ch and the cs are live linked, the rdr writes into 'ch' and
		// this.buf reads from 'cs'
		// but really it's the same place.
		char[] ch = new char[32 * 1024];
		ArrayCharSequence cs = new ArrayCharSequence(ch);

		while ((cnt = rdr.read(ch)) != -1) {
			this.buf.append(cs, 0, cnt);
		}
	}

	/**
	 * Flush any internal buffer to stream in case you want to write to the
	 * underlying stream directly
	 */
	public void flush() throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
	}

	/**
	 * close the current document. Do not add any more content after calling
	 * this method
	 */
	public void close() throws IOException {
		// Finish Element
		if (this.state == State.ATTRIBUTES) {
			this.buf.append('>');
			this.state = State.NORMAL;
		}
		while (this.elements.empty() == false)
			closeElement();
	}

	public XMLBuilder addElement(String element, String content)
			throws IOException {
		return this.openElement(element).characters(content).closeElement();
	}
}
