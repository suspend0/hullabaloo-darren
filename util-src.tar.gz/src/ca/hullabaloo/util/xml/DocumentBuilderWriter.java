package ca.hullabaloo.util.xml;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.w3c.dom.Document;

import ca.hullabaloo.util.io.ProxyWriter;
import ca.hullabaloo.util.sax.SAXUtils;

/**
 * Builds a Document on a <b>secondary thread</b>.
 * 
 * @author Darren Gilroy
 */
public class DocumentBuilderWriter extends ProxyWriter {
	/** The background thread */
	private final FutureTask<Document> task;

	/** If this is closed */
	private boolean closed = false;

	/**
	 * Creates a new BackgroundDocumentBuilder and starts associated background
	 * thread
	 */
	public DocumentBuilderWriter() throws IOException {
		// TODO: A watcher thread to kill this after a time would be useful.
		super(new PipedWriter());
		final PipedWriter wtr = (PipedWriter) this.out;
		final PipedReader rdr = new PipedReader(wtr);
		this.task = new FutureTask<Document>(new Builder(rdr));
		new Thread(this.task).start();
	}

	/**
	 * Returns the built document (blocking call)
	 * 
	 * @throws IOException
	 */
	public Document getDocument() throws InterruptedException,
			ExecutionException, IOException {
		if (!closed)
			this.close();
		Document doc = task.get();
		return doc;
	}

	/** Returns the built document (blocking call) */
	public Document getDocument(long milliseconds) throws InterruptedException,
			ExecutionException, TimeoutException {
		Document doc = task.get(milliseconds, TimeUnit.MILLISECONDS);
		return doc;
	}

	/** Close the reader */
	@Override
	public void close() throws IOException {
		super.close();
		this.closed = true;
	}

	/** This class actually does the building of the document */
	private static class Builder implements Callable<Document> {
		private final PipedReader rdr;

		public Builder(PipedReader rdr) {
			this.rdr = rdr;
		}

		public Document call() throws Exception {
			Document doc = SAXUtils.newDocument(rdr);
			return doc;
		}

	}
}
